/**
 * Classname:Account
 * 
 * 
 * Description:Its the base class for Account subclasses.
 * 
 * Date:30/09/2020
 * */


package com.training.account.model;

import com.training.util.ICalculator;
import com.training.util.IntrestCalculator;


/**
 * The class used for model Account class
 */


public class Account {
	
	


protected	String accountHolderName;
 private	float balance=1000;
 private float amount;
 private	int accountNumber;

 IntrestCalculator ic=new IntrestCalculator(); 

   /**
    * Default Constructor
    */
 
	public Account() {
		
		System.out.println("Inside Default Constructor");
	}
	
	

	
	/***
	 * 
	 * overriding hash code method in object class for genberating hash code for account number 
	 * calling from DoaImplementation
	 */
	
  @Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + accountNumber;
	return result;
}


  /***
   * Overriding Equals method in object class for checking duplicate account number
   * calling from DoaImplementation
   */
  
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Account other = (Account) obj;
	if (accountNumber != other.accountNumber)
		return false;
	return true;
}


/**
 * Parameterized Constructor
 */


	
	public Account(int accountnumber,String holdername,float balanceamount)
	{
		this.accountNumber=accountnumber;
		this.accountHolderName=holdername;
		this.amount=balanceamount;
		this.balance=balanceamount;
		
	}
	
 
   /**
    * Accessor Method for Account number
    */
	
	public int getAccountNumber() {
		return accountNumber;
	}
	
	/**
	 * Accessory Method for Account Account number
	 */
	
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	
	/**
	 * Accessor Method for Account Holder Name
	 */
	
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	
	
	/**
	 * Accessory Method for Account Holder Name
	 */
	
	
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	
	/**
	 * Accessor Method for Account Balance
	 */
	
	public float getBalance() {
		return balance;
	}
	
	
	/**
	 * Accessor Method for Account Amount
	 */
	
	
	public float getAmount() {
		return amount;
	}
	
	
	/**
	 * Accessory Method for Account Amount 
	 */
	
	
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
	/**
	 * Method for wihdrawing the money from account parameter is passed from Account service class
	 */
	
	public void withdrawMoney(float Money) {
		if(balance > Money)
		{
			this.balance=this.balance-Money;
			System.out.println("Balance"+balance);
			
		}
		else
		{
			
			System.out.println("You donn't have enough balance Your balance is"+balance);
		}
		
		

	}
	
	
	/**
	 * Balance updation with amount in the account
	 */
	
	
	public void updateBalance(float amount) {
		
		this.balance=amount;
		System.out.println("Balance In your Account - " +balance);
	}
	

	
	/**
	 * CalculateIntrest is a overridden method and this method is overrides by subclass fd and sd
	 */
	
	
	public void calculateIntreast(float Amt,ICalculator calculator) {
		System.out.println("Inside Account"+Amt);
		
	}
	

	
	
}

/***
 * ClassName:CurrentAccountService
 * 
 * Description:Service Class for the CurrentAccount
 * 
 * Date -06-10-2020
 */


package com.training.accountcollection.service;

import java.util.Collections;
import java.util.Iterator;

import java.util.List;

import com.training.account.dataaccess.CurrentAccountDao;
import com.training.account.dataaccess.CurrentAccountDaoImplementation;
import com.training.account.model.CurrentAccount;
import com.training.account.model.CurrentAccount;

/***
 * This class is used for carry out 3 operation
 * 
 * 1.Getting and displaying all the current account details 
 * 
 * 2.Getting current account details by accountNumber
 * 
 * 3.Delete the current account by AccountNumber
 * 
 */

public class CurrentAccountService {
	
	CurrentAccountDao dao; 

	/**
	 * Constructor for the CurrentAccountService inside the constructor we are creating the object
	 * 
	 * of currentAccount Implementation class
	 * 
	 * */
    
	public CurrentAccountService(){
		
		dao=new CurrentAccountDaoImplementation();
	
	
	}
	
	/***
	 * Displaying all the Current account Returing the current account list to the 
	 * 
	 * Current account retrieval and testgetallcurrentAccount 
	 *  */
	
	public List<CurrentAccount> getallCurrentAccounts()
	{
		List<CurrentAccount> caccounts= dao.getAllCurrentAccount();
		
		
        Iterator<CurrentAccount> iterator = caccounts.iterator();
		
		while(iterator.hasNext())
		{
			CurrentAccount ca=iterator.next();
			
			
			System.out.println("");
		
			System.out.println("Name of Account Holder           -"+ca.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+ca.getAccountNumber());
			
			
			System.out.println("Amount of Account Holder          -"+ca.getAmount());
			
			System.out.println("Amount of Account Holder          -"+ca.getOverdraft());
			
		}
		
	
		
		return caccounts;
	}
	
	/***
	 * Displaying the Account holder details by passing the account number and return the 
	 * 
	 * CAccount object to the current account retrival class and the testgetCurrentAccountByAccountNumber
	 * 
	 */

	public CurrentAccount getCurrentAccountByAccountNumber(int accountNumber)
	{
		CurrentAccount currentAccount=dao.getCurrentAccountByAccountNumber(accountNumber);
		
		
		System.out.println("");
		
		System.out.println("Name of Account Holder           -"+currentAccount.getAccountHolderName());
		
		System.out.println("Account number of Account Holder -"+currentAccount.getAccountNumber());
		
		
		System.out.println("Amount of Account Holder          -"+currentAccount.getAmount());
		
		System.out.println("Amount of Account Holder          -"+currentAccount.getOverdraft());
	    
		
		
		return currentAccount;
	}
	
	/**
	 * Deleting the Current account details by using the accountnumber*/
	
	public void deleteCurrentAccountByAccountNumber(int accountNumber)
	{
		dao.deleteCurrentAccountkByAccountNumber(accountNumber);
		
		
	}
	
	
	/***
	 * Method for getting sorted list of current account  by name,Returning the sorted set 
	 * 
	 * and displaying the sorted list
	 * 
	 */
	public List<CurrentAccount> getAllCurrentAccountSortByHolderName()
	{
		List<CurrentAccount> caAccounts= dao.getAllCurrentAccount();
		
		Collections.sort(caAccounts);
        Iterator<CurrentAccount> iterator = caAccounts.iterator();
		
		while(iterator.hasNext())
		{
			CurrentAccount currentAccount=iterator.next();
			
			
			System.out.println("");
		
			System.out.println("Name of Account Holder           -"+currentAccount.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+currentAccount.getAccountNumber());
			
			
			System.out.println("Amount of Account Holder          -"+currentAccount.getAmount());
			
			System.out.println("Amount of Account Holder          -"+currentAccount.getOverdraft());
			
		}
		return caAccounts;
	}
	
	/***
	 * Method for getting sorted list of current account by Holder balance amount ,Returning the sorted set by 
	 * 
	 * and displaying the sorted list
	 * 
	 */
	
	public List<CurrentAccount> getAllCurrentAccountSortByAccountOverDraft()
	{
List<CurrentAccount> caAccounts= dao.getAllCurrentAccount();
		
		Collections.sort(caAccounts,new CurrentAccountOverdraftComparator());
        Iterator<CurrentAccount> iterator = caAccounts.iterator();
		
		while(iterator.hasNext())
		{
			CurrentAccount currentAccount=iterator.next();
			
			
			System.out.println("");
		
			System.out.println("Name of Account Holder           -"+currentAccount.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+currentAccount.getAccountNumber());
			
			
			System.out.println("Amount of Account Holder          -"+currentAccount.getAmount());
			
			System.out.println("Amount of Account Holder          -"+currentAccount.getOverdraft());
			
		}
		return caAccounts;
	}
	

	/***
	 * 
	 * Displaying the added CurrentAccount is already present or not
	 * 
	 * 	 */

	public void addCurrentAccount(CurrentAccount currentAccount)
	{
		boolean isAdded= dao.addCurrentAccount(currentAccount);
		
		if(isAdded)
		{
			System.out.println("CurrentAccount added Successfully");
			
		}
		
		else
		{
		
			System.out.println("Duplicate Current Account");
			
		}
		
	}
	/***
	 * Updating an Existing Current  Account
	 */
	
	public void updateExistingCurrentAccountAccount(CurrentAccount currentAccount)
	{
		
		dao.updateExistingCurrentAccount(currentAccount);
		
	}
	
	

}

/**
 * ClassName:FixedDepositeDaoImplementation
 * 
 * Description:Implements FixedDepositeDao And doing adding,deleting and searching
 * 
 * Date-06-10-2020
 */



package com.training.account.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.account.model.FixedDeposite;

/***
 * 
 * Implementing All the  abdtract method in fddao Interface
 */

public class FixedDepositeDaoImplementation implements FixedDepositeDao {
	
	
	
	
	List fixedDeposites;
	
	private Set fixedDepositeSet;


	/**
	 * List initialization invoking objects in constructors*/
	
	public FixedDepositeDaoImplementation()
	{
		fixedDeposites = new ArrayList<FixedDeposite>();

		fixedDepositeSet = new HashSet<FixedDeposite>();
		
	/*	FixedDeposite fd1 = new FixedDeposite(1001,"Manu",100,6);
		
		FixedDeposite fd2 = new FixedDeposite(999,"Suku",110,5);

		FixedDeposite fd3 = new FixedDeposite(1000,"Hari",120,8);
		
		fixedDeposites.add(fd1);
		
		fixedDeposites.add(fd2);
		
		fixedDeposites.add(fd3);
*/		
	}
	
   /**
    * Getting the  fd account list*/
	
	@Override
	public List<FixedDeposite> getAllFixedDeposites() {
	
		// TODO Auto-generated method stub
		
		return fixedDeposites;
	}
	
   /**
    * Searching the fd account list by accountnumber 
    * */
	
	@Override
	public FixedDeposite getFixedDepositeByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		FixedDeposite deposite=null;
		
		Iterator<FixedDeposite> iterator= fixedDeposites.iterator();
		
		while(iterator.hasNext())
		{
		   FixedDeposite fd=iterator.next();
		   
			if(fd.getAccountNumber()==accountNumber)
			{
				deposite=fd;
			}
		}
		return deposite;
	}
	
	
/**
 * Deleting the fd account from fd List by using account number
 * 
 * */
	
	@Override
	public void deleteFixedDepositeByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		
		FixedDeposite fixeddeposite=null;
		
		Iterator<FixedDeposite> iterator= fixedDeposites.iterator();
		
		while(iterator.hasNext())
		{
		   FixedDeposite fid=iterator.next();
		   
			if(fid.getAccountNumber()==accountNumber)
			{
				fixeddeposite=fid;
			}
		}
		
		fixedDeposites.remove(fixeddeposite);
		
	}

/***
 * This method is for Adding a new Deposit to a Set by avoiding duplicates. Service class method is 
 * 
 * calling this method
 */
	
	@Override

	public boolean addFixedDepositeAccount(FixedDeposite fixedDeposite) {
	
	// TODO Auto-generated method stub
		
		boolean isAdded= fixedDepositeSet.add(fixedDeposite);
		
		if(isAdded)
		{
			
			fixedDeposites.add(fixedDeposite);
		}
		
	return isAdded;
}
	
	/***
	 * This method is for updating an existing Fd Account
	 */

@Override
public void updateExistingFixedDepositeAccount(FixedDeposite fixedDeposite) {
	// TODO Auto-generated method stub
	Iterator iterator = fixedDeposites.iterator();

	while(iterator.hasNext())
	{
		FixedDeposite fd = (FixedDeposite) iterator.next();
		
		if(fd.getAccountNumber()==fixedDeposite.getAccountNumber())
		{
			
			fd.setAccountHolderName(fixedDeposite.getAccountHolderName());
			
			fd.setAmount(fixedDeposite.getAmount());
		}
		
		
	}
	
}
	
	
	
	

}

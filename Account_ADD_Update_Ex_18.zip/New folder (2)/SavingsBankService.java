/***
 * ClassName:SavingBankService
 * 
 * Description:Service class for the implementation of SavingBankDaoImplementation
 * 
 * Date-06-10-2020
 */


package com.training.accountcollection.service;

import java.util.Collections;
import java.util.Iterator;

import java.util.List;

import com.training.account.dataaccess.SavingsBankDao;
import com.training.account.dataaccess.SavingsBankDaoImplementations;

import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;

/***
 * SavingsBankService Class is used for 
 * 
 * 1.Displaying all savings Bank account
 * 
 * 2.Displaying particular savings Bank account by accountNumber
 *
 * 3.Delete the Savings Bank Account by accountNumber
 */

public class SavingsBankService {
	
	SavingsBankDao dao; 

	/**
	 * Constructor used for creating SavingsBankDaoImplementation Object
	 * 
	 * */
    
	public SavingsBankService(){
		
		dao=new SavingsBankDaoImplementations();
	
	
	}
	/**
	 * This method display all the account details inside the sb List and 
	 * Returning the retrieved List to Service and test class
	 * */
	
	public List<SbAccount> getallSavingsBankDeposite()
	{
		List<SbAccount> sbAccounts= dao.getAllSavingsBankDeposite();
		
		
        Iterator<SbAccount> iterator = sbAccounts.iterator();
		
		while(iterator.hasNext())
		{
			SbAccount sb =iterator.next();
			
			
			System.out.println("");
		
			System.out.println("Name of Account Holder           -"+sb.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+sb.getAccountNumber());
			
			
			System.out.println("Amount of Account Holder          -"+sb.getAmount());
			
		}
		
	
		
		return sbAccounts;
	}
	
/**
 * Getting the SbAccount details using AccountNumber ,display the details and return the 
 * specified object
 * 
 * */
	
	public SbAccount getSavingsBankByAccountNumber(int accountNumber)
	{
		SbAccount sbAccount=dao.getSavingsBankByAccountNumber(accountNumber);
		
		
		System.out.println("Name Of Account Holder     - "+sbAccount.getAccountHolderName());
		
		System.out.println("Account number of Account Holder -"+sbAccount.getAccountNumber());
		
		
		System.out.println("Amount of Account Holder          -"+sbAccount.getAmount());
		
		
		return sbAccount;
	}
	
	/**
	 * Delete the SbAccount using Account number
	 * */
	
	public void deleteSavingsBankAccount(int accountNumber)
	{
		dao.deleteSavingsBankByAccountNumber(accountNumber);
		
		
	}
	
	
	/***
	 * Method for getting sorted list of Sb account  by name,Returning the sorted set 
	 * 
	 * and displaying the sorted list
	 * 
	 */
	
	public List<SbAccount> getAllSbAccountSortByHolderName()
	{
		List<SbAccount> sbAccountList= dao.getAllSavingsBankDeposite();
		
		Collections.sort(sbAccountList);
		
		Iterator<SbAccount> iterator = sbAccountList.iterator();
		
		while(iterator.hasNext())
		{
			SbAccount savingsAccount = iterator.next();
			
			System.out.println("");
			
			System.out.println("Name of Account Holder           -"+savingsAccount.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+savingsAccount.getAccountNumber());
				
			System.out.println("Amount of Account Holder          -"+savingsAccount.getAmount());
			
		
			
		}
		return sbAccountList;
	}
	
	/***
	 * Method for getting sorted list od Sb account by Holder balance amount ,Returning the sorted set by 
	 * 
	 * and displaying the sorted list
	 * 
	 */
	
	public List<SbAccount> getAllSbAccountSortByAccountBalance()
	{
		List<SbAccount> SbAccountAmountSortingLists = dao.getAllSavingsBankDeposite();
		
		Collections.sort(SbAccountAmountSortingLists, new AccountBalanceComparator());

		
		Iterator<SbAccount> iterator = SbAccountAmountSortingLists.iterator();
		
		while(iterator.hasNext())
		{
			SbAccount sbAccount = iterator.next();
			

			System.out.println("");
			
			System.out.println("Name of Account Holder           -"+sbAccount.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+sbAccount.getAccountNumber());
				
			System.out.println("Amount of Account Holder          -"+sbAccount.getAmount());
			
		
		
	}
	
	return SbAccountAmountSortingLists;
}
	

	/***
	 * 
	 * Displaying the added SavingsAccount and printing account is already present or not
	 * 
	 * 	 */

	public void addSavingsAccount(SbAccount savingsAccount)
	{
		boolean isAdded= dao.addSavingsAccount(savingsAccount);
		
		if(isAdded)
		{
			System.out.println("SavingsAccount added Successfully");
			
		}
		
		else
		{
		
			System.out.println("Duplicate Savings Account");
			
		}
		
	}
	/***
	 * Updating an Existing Savings  Account
	 */
	
	public void updateExistingSavingsAccount(SbAccount savingsAccount)
	{
		
		dao.updateExistingSavingsAccount(savingsAccount);
		
	}
	
	


	
}

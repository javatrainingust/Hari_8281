/***
 * 
 * ClassName:BalanceComparator
 * 
 * Descriptions:For comparing fixeddeposite by Balance amount
 * 
 * Date-07-10-2020
 * 
 */



package com.training.accountcollection.service;

import java.util.Comparator;

import com.training.account.model.FixedDeposite;

/***
 * This method implementing the Comparator and overriding the compare method
 * 
 */

public class BalanceComparator implements Comparator<FixedDeposite> {

	/***
	 * 
	 * Getting the Fd objects as the arguments and comparing and return assccending order result set
	 * 
	 */
	@Override
	public int compare(FixedDeposite fixedDeposite1, FixedDeposite fixedDeposite2) {
		
		// TODO Auto-generated method stub
		
		return (int) (fixedDeposite1.getAmount()-fixedDeposite2.getAmount());
	}

}

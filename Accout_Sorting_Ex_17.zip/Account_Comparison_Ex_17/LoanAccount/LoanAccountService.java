/***
 * ClassName:LoanAccountService
 * 
 * Description:Service Class for loanAccount
 * 
 * Date-06-10-2020
 * 
 */



package com.training.accountcollection.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.account.dataaccess.LoanAccountDao;
import com.training.account.dataaccess.LoanAccountDaoImplementation;
import com.training.account.model.FixedDeposite;
import com.training.account.model.LoanAccount;

/***
 * This class is for Loan Account.It will 
 * 
 * 1display all the loan Accounts
 * 
 * 2.Particular LoanAccount by id
 * 
 * 3.Delete a Loan Account
 * 
 */

public class LoanAccountService {
	
	
	LoanAccountDao dao; 

	/**
	 * Constructor create the LoanAccountDaoImplementation Object for calling Methods in LoanAccountDaoImplementation
	 * Class
	 * 
	 *  */
    
	public LoanAccountService(){
		
		dao=new LoanAccountDaoImplementation();
	
	
	}
	

	/**This method is for 3 Operations
	 * 
	 * 1.Getting all the Loan Accounts
	 * 
	 * 2.Displaying all the Loan Accounts
	 * 
	 * 3.Returning List to Test and LoanRetrivalDemo
	 *  */
	
	public List<LoanAccount> getallLoanAccounts()
	{
		List<LoanAccount> laccounts= dao.getAllLoantAccount();
		
		
		
        Iterator<LoanAccount> iterator = laccounts.iterator();
		
		while(iterator.hasNext())
		{
			LoanAccount lAcccountDeposite =iterator.next();
			
			
			System.out.println("");
		
			System.out.println("Name of Account Holder           -"+ lAcccountDeposite.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+ lAcccountDeposite.getAccountNumber());
			
			System.out.println("Amount of Account Holder          -"+ lAcccountDeposite.getAmount());
			
			System.out.println("OutStanding Amount        -"+ lAcccountDeposite.getOutstandingAmount());
			
		}
		
	
		
		return laccounts;
	}

	/**
	 * This method is for one operation
	 * 
	 * 1.Getting the particular account by accountNumber
	 * 
	 * 2.Returning the LoanAccountObject to the LoanRetrival and Test 
	 * 
	 * */

	public LoanAccount getLoanAccountByAccountNumber(int accountNumber)
	{
		LoanAccount lAccount=dao.getLoanAccountByAccountNumber(accountNumber);
		
		
		System.out.println("Name Of Account Holder     - "+lAccount.getAccountHolderName());
		
		System.out.println("Account number of Account Holder -"+lAccount.getAccountNumber());
		
		
		System.out.println("Outstanding Amount               -"+lAccount.getAmount());
		
	    
		
		
		return lAccount;
	}
	
	/**
	 * This method is used for Delete the loanAccount by Account number
	 *  */
	public void deleteLoanBankAccount(int accountNumber)
	{
		dao.deleteLoanAccountkByAccountNumber(accountNumber);
		
		
	}
	
	
	
	/***
	 * Method for getting sorted list of LoanAccount   by name,Returning the sorted set 
	 * 
	 * and displaying the sorted list
	 * 
	 */
	public List<LoanAccount> getAllLoanAccountSortByHolderName()
	{
	List<LoanAccount> laccounts= dao.getAllLoantAccount();
		
		Collections.sort(laccounts);
		
        Iterator<LoanAccount> iterator = laccounts.iterator();
		
		while(iterator.hasNext())
		{
			LoanAccount lAcccountDeposite =iterator.next();
			
			
			System.out.println("");
		
			System.out.println("Name of Account Holder           -"+ lAcccountDeposite.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+ lAcccountDeposite.getAccountNumber());
			
			System.out.println("Amount of Account Holder          -"+ lAcccountDeposite.getAmount());
			
			System.out.println("Outstanding Amount                -"+ lAcccountDeposite.getOutstandingAmount());
			
		}
		
	
		
		return laccounts;
	}
	
	/***
	 * Method for getting sorted list of LoanAccount by  Holder balance amount ,Returning the sorted set by 
	 * 
	 * and displaying the sorted list
	 * 
	 */
	
	public List<LoanAccount> getAllLoanAccountSortByOutstanding()
	{
	List<LoanAccount> laccounts= dao.getAllLoantAccount();
		
		Collections.sort(laccounts,new LoanAccountOutStandingAmountComparator());
		
        Iterator<LoanAccount> iterator = laccounts.iterator();
		
		while(iterator.hasNext())
		{
			LoanAccount lAcccountDeposite =iterator.next();
			
			
			System.out.println("");
		
			System.out.println("Name of Account Holder           -"+ lAcccountDeposite.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+ lAcccountDeposite.getAccountNumber());
			
			System.out.println("Amount of Account Holder          -"+ lAcccountDeposite.getAmount());
			
			System.out.println("Outstanding Amount                 -"+ lAcccountDeposite.getOutstandingAmount());
			
		}
		
	
		
		return laccounts;
	

}
}
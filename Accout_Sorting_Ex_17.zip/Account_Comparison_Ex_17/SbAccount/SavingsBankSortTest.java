/***
 * ClassName:SavingBankSortTest
 * 
 * Description: Testing name and holderAmount sorting
 * 
 * Date - 07-10-2020
 * 
 */


package com.training.accountcollection.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;

/***
 * Test Class for testing GetAllSbAccountSortByHolderName,GetAllSbAccountSortByAccountBalance
 * 
 * methods both resides in service class
 * 
 */

public class SavingsBankSortTest {

	SavingsBankService service = new SavingsBankService();
	 List<SbAccount> savingsBankAccount;
	
	
	/***
	 *  2 Testing 
	 *  
	 *  1 by size of SbList
	 *  
	 *  2  by First name comparison
	 */
	
	@Test
	public void testGetAllSbAccountSortByHolderName() {
		
		String expectedValue="Amal";
        savingsBankAccount	=service.getAllSbAccountSortByHolderName();
		String actualValue = savingsBankAccount.get(0).getAccountHolderName();
        assertEquals(expectedValue, actualValue);
        assertEquals(3, savingsBankAccount.size());

	}
	
	

	/***
	 *  2 Testing
	 *  
	 *  1 by size of SbList
	 *  
	 *  2  by First amount comparison
	 */

	@Test
	public void testGetAllSbAccountSortByAccountBalance() {

		float expected=100.f;
		  savingsBankAccount=service.getAllSbAccountSortByAccountBalance();
			float actual =savingsBankAccount.get(0).getAmount();
			assertEquals(expected, actual,0.0f);
	        assertEquals(3,savingsBankAccount.size());
		
		
	}

}

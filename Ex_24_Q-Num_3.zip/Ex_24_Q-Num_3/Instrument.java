/***
 * InterfaceName:Instrument
 * 
 * Description:instrument interface with one method delcaration
 * 
 * Date-12-10-2020
 */



package com.training.walmart.secondspring;

/***
 *Instrument interface for  play() method declaration 
 *
 */


public interface Instrument {
	
	/*Play method declaration used by Saxaphone */
	
	public void play();

}

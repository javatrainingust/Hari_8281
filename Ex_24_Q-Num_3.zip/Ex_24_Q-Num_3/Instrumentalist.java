/***
 * ClassName : Instrumentalist
 * 
 * Description  : pojo Class for instrumentalist
 * 
 * 
 * Date -12-10-2020
 */


package com.training.walmart.secondspring;

/***
 * Class Implementing performer interface and contain perform fuction
 * 
 * One obj pramenter of type Saxsaphone 
 * 
 * Getters and setters for saxaphone (Saxaphone obj passing from the music context bean)
 *
 * 
 * 
 */


public class Instrumentalist implements Performer {
	
	Saxaphone saxaphonee;

	public Saxaphone getSaxaphonee() {
		return saxaphonee;
	}

	public void setSaxaphonee(Saxaphone saxaphonee) {
		this.saxaphonee = saxaphonee;
	}

	/**
	 * Implemented perform method definition calling saxaphone implemented method play
	 *  
	 *  Implemented from Instrument
	 */
	
	public void perform()
	{
		/*play Method call in Saxsaphone */
		saxaphonee.play();
	}
}

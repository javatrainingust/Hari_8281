/**
 * InterfaceName: CurrentAccountDao
 * 
 * Description:Interface for adding,retrieving,deleting details in currentAccount
 * 
 * Date -06-10-2020
 */



package com.training.account.dataaccess;

import java.util.List;

import com.training.account.model.CurrentAccount;
import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;
/***
 * This interface is implemented by CurrentAccountDaoImplementation, contains 3 methods
 * 
 */

public interface CurrentAccountDao {
	
	/*Method declaration for getting all the current accounts and is  implemented in CurrentAccountDaoImplementation*/
	public List<CurrentAccount> getAllCurrentAccount();
	
	/*Method declaration for getting  the current account by Account num and is implemented in CurrentAccountDaoImplementation*/
	public CurrentAccount getCurrentAccountByAccountNumber(int accountNumber);
	
	/*Method declaration for deleting   the current accounts and is  implemented in CurrentAccountDaoImplementation*/
	public void deleteCurrentAccountkByAccountNumber(int accountNumber);


	/* Adding CurrentAccount and then checking for duplicate*/
	
	public boolean addCurrentAccount(CurrentAccount currentAccount);
	
	/*Updating an existing Current Account*/
	
	public void updateExistingCurrentAccount(CurrentAccount currentAccount);
	
}

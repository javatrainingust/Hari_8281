/***
 * ClassName: CurrentAccountDaoImplementation 
 * 
 * Description:Implementing the currentAccountDao
 * 
 * Date :06-10-2020
 * 
 */



package com.training.account.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.training.account.model.CurrentAccount;
import com.training.account.model.FixedDeposite;
/***
 * 
 * Implementing all the abstract methods CurrentAccountdao interface
 * @repository is used for creating CurrentAccountDaoImplementation
 */

@Repository
public class CurrentAccountDaoImplementation implements CurrentAccountDao {

	List currentAccounts;
	
	private Set currentAccountSet;
	
	/**
	 * Adding current  to list and invoking objects in constructors*/
	
	public CurrentAccountDaoImplementation()
	{
		

	 currentAccounts = new ArrayList<CurrentAccount>();
	
	 currentAccountSet = new HashSet<CurrentAccount>();
	 
	 CurrentAccount ca1 = new  CurrentAccount(1001,"Manu",110,500);
	
	 CurrentAccount ca2 = new  CurrentAccount(1000,"Hari",100,1000);

	 CurrentAccount ca3 = new  CurrentAccount(1002,"Suku",120,300);
	
	 currentAccounts.add(ca1);
	
	 currentAccounts.add(ca2);
	
	 currentAccounts.add(ca3);
	
	}
	
	/**Getting current account List and return to current acount service class*/
	
	@Override
	public List<CurrentAccount> getAllCurrentAccount() {
		// TODO Auto-generated method stub
		return currentAccounts;
	}
	
	
    /**Searching current account using Accountnumber*/

	@Override
	public CurrentAccount getCurrentAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		
	    CurrentAccount currentAccount=null;
		
		Iterator<CurrentAccount> iterator=currentAccounts.iterator();
		
		while(iterator.hasNext())
		{
		   CurrentAccount deposite=iterator.next();
		   
			if(deposite.getAccountNumber()==accountNumber)
			{
				currentAccount=deposite;
			}
		}
		return currentAccount;

	}

	/**
	 * Deleting current account using Accountnumber*/
	
	@Override
	public void deleteCurrentAccountkByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		
        CurrentAccount cAccount=null;
		
		Iterator<CurrentAccount> iterator = currentAccounts.iterator();
		while(iterator.hasNext())
		{
			CurrentAccount cad=iterator.next();
			
			if(cad.getAccountNumber()==accountNumber)
			{
				
				cAccount=cad;
			}
			
			
		}
		
		currentAccounts.remove(cAccount);
	}

	/***
	 * Adding current account avoiding duplicates
	 * 
	 */
	
	@Override
	public boolean addCurrentAccount(CurrentAccount currentAccount) {
		// TODO Auto-generated method stub
	boolean isAdded= currentAccountSet.add(currentAccount);
		
		if(isAdded)
		{
			
			currentAccounts.add(currentAccount);
		}
		
	return isAdded;
	}

	
	/***
	 * Updating exidting Currunt account details by account number
	 */
	@Override
	public void updateExistingCurrentAccount(CurrentAccount currentAccount) {
		// TODO Auto-generated method stub
		Iterator iterator = currentAccounts.iterator();

		while(iterator.hasNext())
		{
			CurrentAccount current = (CurrentAccount) iterator.next();
			
			if(current.getAccountNumber()==currentAccount.getAccountNumber())
			{
				
				current.setAccountHolderName(currentAccount.getAccountHolderName());
				
				current.setAmount(currentAccount.getAmount());
			}
			
			
		}
		
	}
	
}



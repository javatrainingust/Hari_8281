/**
 * InterfaceName:  LoanAccountDao
 * 
 * Description:Interface for adding,retrieving,delete details in  LoanAccountDao
 * 
 * Date -06-10-2020
 */



package com.training.account.dataaccess;

import java.util.List;
import com.training.account.model.LoanAccount;
import com.training.account.model.LoanAccount;


/***
 * Interface for LoanAccount and is implemented by LoanAccountDaoImplementation
 *  
 */

public interface LoanAccountDao {
	
	/*Method declaration for getting all the fd accounts and is implemented in FixedDepositeDaoImplementation*/

	public List<LoanAccount> getAllLoantAccount();

	/*Method declaration for getting all the fd accounts and is implemented in FixedDepositeDaoImplementation*/
	public LoanAccount getLoanAccountByAccountNumber(int accountNumber);
	

	/*Method declaration for getting all the fd accounts and is implemented in FixedDepositeDaoImplementation*/
	public void deleteLoanAccountkByAccountNumber(int accountNumber);
	
	

	/* Adding LoanAccount and then checking for duplicate*/
	
	public boolean addLoanAccount(LoanAccount LoanAccount);
	
	/*Updating an existing Loan Account*/
	
	public void updateExistingLoanAccount(LoanAccount LoanAccount);
	


}

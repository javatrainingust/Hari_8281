/**
 * InterfaceName:RenewalAccount
 * 
 * 
 * Description:It is and interface that we have been using for renew the account for a tenure.Implemented by
 * Fixed Deposite class only
 * 
 * Date:30/09/2020
 * */


package com.training.account.model;


public interface RenewalAccount {
	

	public void autoRenewal(int tenure);
	

}

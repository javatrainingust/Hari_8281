/***
 * ClassName:Saving accountaddsdemo
 * 
 * Description:Class for the initiation of SbAccount Add process
 * 
 * Date-08-10-2020
 */
package com.training.accountcollection.service;

import com.training.account.model.SbAccount;

/***
 * 
 * Initiation of sb Account add account process
 * 
 */

public class SavingsAcoountAddDemo {

	
	/***
	 * 
	 * Main Method
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		SavingsBankService savingsBankService = new SavingsBankService();

		System.out.println("Adding new Accounts.............");


		System.out.println(".............");


		savingsBankService.addSavingsAccount( new SbAccount(100,"Harikrishnan",100));

		savingsBankService.addSavingsAccount(new SbAccount(10,"Krishnan",1000));

		savingsBankService.addSavingsAccount( new SbAccount(12,"Amal",500));
		
		savingsBankService.addSavingsAccount( new SbAccount(12,"Amal",500));

		savingsBankService.getallSavingsBankDeposite();
		

		System.out.println("Adding new Accounts.............");


		System.out.println(".............");

        savingsBankService.updateExistingSavingsAccount(new SbAccount(12,"Amal Krishna",500));
        
        savingsBankService.getallSavingsBankDeposite();

	}

}

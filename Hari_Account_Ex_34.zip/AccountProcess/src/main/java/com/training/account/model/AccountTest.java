/**
 * ClassName: Account Test
 * 
 * Description: Testing 2 methods in Account Model Class
 * 
 * Date 01/10/2020
 *  
 *  */


package com.training.account.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class AccountTest {
	
	Account account = new Account();

	
	
	/**
	 * Testing Withdrawal method in Account Class
	 
	 */
	
	@Test
    public void testWithdrawMoney() {
	
		double expectedBalance=500.0f;
		
		float delta=.0f;
		
		account.withdrawMoneym(500);
		
		double actualBalance=account.getBalance();
		
		assertEquals(expectedBalance,actualBalance,delta);
		
	}

	
	/**
	 * Testing UpdateBalance method in Account Class
	 */
	
	
	
	@Test
	public void testUpdateBalance() {
		
		float deltaAmount=.0f;
		
		float expectedAmount=100;
		
     	account.updateBalance(100);
     	
     	float actualAmount=account.getBalance();
		 
     	assertEquals(expectedAmount, actualAmount,deltaAmount);
	     
		
		
	}

}

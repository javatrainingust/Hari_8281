/***
 * ClassName:CurrentAccountDemo
 * 
 * Description:Initiation of add and update methods of current account class
 * 
 * Date 08-10-2020
 * 
 */

package com.training.accountcollection.service;

import com.training.account.model.CurrentAccount;

/**
 * 
 * This class for Initiation of add and update methods of current account class
 */
public class CurrentAccountAddDemo {

	
	/***
	 * 
	 * Main method Execution calling service class methods from here
	 * */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	      CurrentAccountService accountService = new CurrentAccountService();

		 
         System.out.println("Adding new Accounts.............");
 		
 		System.out.println(".............");
		
 		accountService.addCurrentAccount(new  CurrentAccount(1001,"Manu",110,500));
 		
 		accountService.addCurrentAccount( new  CurrentAccount(1000,"Hari",100,1000));
 		
 		accountService.addCurrentAccount( new  CurrentAccount(1002,"Suku",120,300));
 		
 		accountService.addCurrentAccount( new  CurrentAccount(1002,"Suku",120,300));
 		
 		accountService.getallCurrentAccounts();

		 
        System.out.println("updating Exicting Accounts.............");
		
		System.out.println(".............");
		
		accountService.updateExistingCurrentAccountAccount(new  CurrentAccount(1002,"Sukumar",120,300));
		
		accountService.getallCurrentAccounts();
 		
 		
	}

}

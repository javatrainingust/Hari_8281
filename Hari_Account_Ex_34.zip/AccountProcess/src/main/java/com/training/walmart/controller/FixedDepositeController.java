/***
 * ClassName:FixedDepositeController
 * 
 * Description:Class for getting all the fixedDeposite details
 * 
 * Date-15-10-2020
 */

package com.training.walmart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.account.model.FixedDeposite;
import com.training.accountcollection.service.FixedDepositeService;

@Controller
public class FixedDepositeController {
	
	/*FixedDeposite service class object is created using autowired annotation*/
	
	@Autowired
	private FixedDepositeService fdservice;
/***
 * url / showForm maps to this method 
 * 
 * create the fd object and  adding to model attribute 
 * 
 * and returning the addfdAccount
 * 
 * @param model
 * 
 * @return addFdAccount
 */
	@RequestMapping("/showFdForm")
	public String showFd(Model model)
	{
		FixedDeposite fixedDeposite = new FixedDeposite();
		model.addAttribute("fdKey",fixedDeposite);
		return "addFdAccount";
	}
	/***
	 *  /addFd url maps to this method and calls the service object method add fd
	 *  
	 *   also passing fd object and redirect to /fixedDeposite 
	 * 
	 * @param fd
	 * 
	 * @return fixed Deposite
	 */
	
	@RequestMapping("/addFd")
	public String addFd(@ModelAttribute("FixedDeposite") FixedDeposite fd)
	{
		fdservice.addFixedDepositeAccount(fd);
	
		
		return "redirect:/fixeddeposite" ;
	}
	
	


	/***
	 * Url ending with /fixeddeposite mapped to get all deposite method
	 * 
	 * @param model
	 * 
	 * @return fixedDepositeList page in view
	 * 
	 * getting all the fd account and adding to model 
	 */
	
	@RequestMapping("/fixeddeposite")
	public String getAllDeposite(Model model)
	{
		System.out.println("Inside the controller getallFixedDeposite");
	List<FixedDeposite> fixedDepositeList =fdservice.getAllFixedDposites();	
		model.addAttribute("FdList",fixedDepositeList);
		
		return "fixedDepositeList";
	}
	

/***
* Method for getting the details of an Fixed account by account number and assignig
* 
* to model
*
* @param id -passing through query string
* @param model - Fd model used by fd account view(viewFixedDeposite)
* @return - returning view (viewFixedDeposite)
*/
	
	@RequestMapping("/viewFdAccount")
	public String getFdAccount(@RequestParam("id") String id,Model model){
		
		FixedDeposite fdDeposite= fdservice.getFixedDepositeByAccountNumber(Integer.parseInt(id));
		
		model.addAttribute("fixedDeposite",fdDeposite);
		
		return "viewFixedDeposite";
	}

	
	/***
	* Method for getting the details of an Fixed account by account number and deleting 
	* 
	* it and redirect to fixeddeposite list
	*
	* @param id -passing through query string
	* 
	* @return - redirecting view (fixedDeposite)
	*/
		
		@RequestMapping("/deleteFdAccount")
		public String getdeleteAccount(@RequestParam("id") String id,Model model){
			
			fdservice.deleteFixedDepositeAccount(Integer.parseInt(id));
			
			
			
			return "redirect:/fixeddeposite";
		}

}

/**
 * InterfaceName:  SavingsBankDao
 * 
 * Description:Interface for adding,retrieving,delete details in SavingsBankDao
 * 
 * Date -06-10-2020
 */


package com.training.account.dataaccess;

import java.util.List;

import com.training.account.model.CurrentAccount;
import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;

public interface SavingsBankDao {

	/*Method declaration for getting all the sb accounts and is implemented in SavingsBankDaoImplementation*/

	public List<SbAccount> getAllSavingsBankDeposite();
	

	/*Method declaration for getting all the sb accounts and is implemented in SavingsBankDaoImplementation*/

	public SbAccount getSavingsBankByAccountNumber(int accountNumber);
	
	/*Method declaration for getting all the sb accounts and is implemented in SavingsBankDaoImplementation*/
	
	public void deleteSavingsBankByAccountNumber(int accountNumber);
	

	/* Adding Savings and then checking for duplicate*/
	
	public boolean addSavingsAccount(SbAccount sbAccount);
	
	/*Updating an existing Savings Account*/
	
	public void updateExistingSavingsAccount(SbAccount sbAccount);
	
}

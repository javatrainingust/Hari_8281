/***
 * ClassName : FixedDepositeSortDemo
 * 
 * Description:Main method for sorting FdAccount by holdername and amount
 * 
 * Date-07-10-2020
 */



package com.training.accountcollection.service;

import java.security.Provider.Service;

/***
 * Main method where the execution started for sorting the Fd account by holders name and amount
 * 
 * Calling Fdservice class methods using the Service object 2 methods getAllFixedDposites()
 * 
 * getAllFixedDepositeSortByHolderName
 * 
 */



public class FixedDepositeSortDemo {

	
	/***
	 * 
	 * Main Method Execution Starts here.
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FixedDepositeService service = new FixedDepositeService();
		
		System.out.println("List Before Sorting");
		
		service.getAllFixedDposites();
		
        System.out.println("");
		
		System.out.println("List After Sorting");
		
		System.out.println("-------------");
		

		service.getAllFixedDepositeSortByHolderName();
		
		
	    System.out.println("");
		
		System.out.println("Sorting by Amount");
		

        System.out.println("--------------------");
		
		 service.getAllFixedDepositeSortByAccountBalance();
		
        
		

		

	}

}

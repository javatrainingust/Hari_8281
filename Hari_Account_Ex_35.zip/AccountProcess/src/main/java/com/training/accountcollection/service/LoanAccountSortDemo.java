/***
 * ClassName : LoanAccountSortDemo
 * 
 * Description:Main method for sorting LoanAccount by holdername
 * 
 * Date-07-10-2020
 */



package com.training.accountcollection.service;


/***
 * Main method where the execution started for sorting the Loan account by holders name
 * 
 * Calling LoanAccountservice class methods using the Service object 2 methods getAllloanAccountSortByHoldername()
 * 
 * getAllLoanAccountSortByOutstandingLimit
 * 
 */

public class LoanAccountSortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	   LoanAccountService service = new LoanAccountService();
		
		System.out.println("List Before Sorting");
		
		service.getallLoanAccounts();
		
        System.out.println("");
		
		System.out.println("List After Sorting");
		
		System.out.println("-------------");
		

		service.getAllLoanAccountSortByHolderName();
		
		
	    System.out.println("");
		
		System.out.println("Sorting by Amount");
		

        System.out.println("--------------------");
		
		 service. getAllLoanAccountSortByOutstanding();
		
        
		

	}

}

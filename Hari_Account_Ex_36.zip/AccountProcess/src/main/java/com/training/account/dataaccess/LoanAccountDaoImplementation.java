/***
 * ClassNAme:LoanAccountDaoImplementation
 * 
 * Description:Implementing LoanAccountDao
 * 
 * Date -06-10-2020
 */




package com.training.account.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.training.account.model.CurrentAccount;
import com.training.account.model.FixedDeposite;
import com.training.account.model.LoanAccount;
import com.training.account.model.LoanAccount;

/**
 * Implementing all the abstract methods in Loan Dao interface
 * @repository is used for creating LoanAccountDaoImplementation
 */

@Repository
public class LoanAccountDaoImplementation implements LoanAccountDao {
	
	
	List loanAccounts;
	
	private Set loanAccountSet;

	/**
	 * Adding to List invoking objects in constructors*/

	public LoanAccountDaoImplementation()
	{
		

	 loanAccounts = new ArrayList<LoanAccount>();
	
	 loanAccountSet = new HashSet<LoanAccount>();
	 LoanAccount la1 = new  LoanAccount(1000,"Manu",100,5000);
	

	 LoanAccount la2 = new  LoanAccount(1001,"Hari",110,1000);

	 LoanAccount la3 = new  LoanAccount(1002,"Suku",120,2000);
	
	 loanAccounts.add(la1);
	
	 loanAccounts.add(la2);
	
	 loanAccounts.add(la3);
	 
	 loanAccountSet.add(la1);
	 

	 loanAccountSet.add(la2);

	 loanAccountSet.add(la3);
	
	}
	

	/**
	 * Retrieving  Loan accounts*/
	
	@Override
	public List<LoanAccount> getAllLoantAccount() {
		// TODO Auto-generated method stub
		return loanAccounts;
	}

	/**
	 * Retrieving Loan Account by AccountNumber*/
	
	@Override
	public LoanAccount getLoanAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		
		LoanAccount lAccount=null;
			
			Iterator<LoanAccount> iterator=loanAccounts.iterator();
			
			while(iterator.hasNext())
			{
			   LoanAccount loanAccountDeposite=iterator.next();
			   
				if( loanAccountDeposite.getAccountNumber()==accountNumber)
				{
					lAccount= loanAccountDeposite;
				}
			}
			

		return lAccount;
	}

	/**
	 * Deleting Loan account by AccountNumber*/
	@Override
	public void deleteLoanAccountkByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub

		LoanAccount account=null;
		
		Iterator<LoanAccount> iterator=loanAccounts.iterator();
		
		while(iterator.hasNext())
		{
		   LoanAccount lDeposite=iterator.next();
		   
			if(lDeposite.getAccountNumber()==accountNumber)
			{
				account=lDeposite;
			}
		}
		
     loanAccounts.remove(account);
		
	}

/***
 * Adding loan account avoiding duplicates
 */
	
	
	@Override
	public boolean addLoanAccount(LoanAccount loanAccount) {
	boolean isAdded= loanAccountSet.add(loanAccount);
		
		if(isAdded)
		{
			
			loanAccounts.add(loanAccount);
		}
		
	return isAdded;
	}
	
	
	/***
	 * Updating exicting Loan account
	 */


	@Override
	public void updateExistingLoanAccount(LoanAccount loanAccount) {
		// TODO Auto-generated method stub
		Iterator iterator = loanAccounts.iterator();

		while(iterator.hasNext())
		{
		     LoanAccount la = (LoanAccount) iterator.next();
			
			if(la.getAccountNumber()==loanAccount.getAccountNumber())
			{
				
				la.setAccountHolderName(loanAccount.getAccountHolderName());
				
				la.setAmount(loanAccount.getAmount());
			}
			
			
		}
		
	}

}

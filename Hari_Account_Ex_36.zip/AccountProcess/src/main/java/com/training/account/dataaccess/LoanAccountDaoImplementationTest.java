/***
 * ClassName:LoanAccountDaoImplementationTest
 * 
 * Description:Testing LoanAccountDaoImplementation Class
 * 
 * Date-06-10-2020
 * 
 */

package com.training.account.dataaccess;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.training.account.model.LoanAccount;
import com.training.account.model.SbAccount;


public class LoanAccountDaoImplementationTest {

	LoanAccountDao dao = new LoanAccountDaoImplementation();
	
	LoanAccount la = new LoanAccount();
	
	/*testing getter*/
	@Test
	public void testGetAllLoantAccount() {
      
		int expected=3;
	    List<LoanAccount> actual=dao.getAllLoantAccount();
		assertEquals(expected,actual.size());
	}
	
	/*testing get by accnt num*/

	@Test
	public void testGetLoanAccountByAccountNumber() {
	String expectedValue="Hari";
		
		la=dao.getLoanAccountByAccountNumber(1000);
		
		String actualValue=la.getAccountHolderName();
	
		assertEquals(expectedValue,actualValue);
	}

	
	/*testing delete*/
	@Test
	public void testDeleteLoanAccountkByAccountNumber() {
		
		
		int expectedSize=2;
		dao.deleteLoanAccountkByAccountNumber(1000);
		List<LoanAccount> actual=dao.getAllLoantAccount();

		assertEquals(expectedSize, actual.size());	}

}

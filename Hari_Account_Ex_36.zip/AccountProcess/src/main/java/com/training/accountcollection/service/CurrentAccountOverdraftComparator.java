/***
 * 
 * ClassName:CurrentAccountOverdraftComparator
 * 
 * Descriptions:For comparing CurrentAccount by OverDraft amount
 * 
 * Date-07-10-2020
 * 
 */


package com.training.accountcollection.service;

import java.util.Comparator;

import com.training.account.model.CurrentAccount;

/***
 * This method implementing the Comparator and overriding the compare method
 * 
 */


public class CurrentAccountOverdraftComparator implements Comparator<CurrentAccount> {

	/***
	 * 
	 * Getting the CurrentAccount objects as the arguments and comparing and return assccending order result set
	 * 
	 */
	

	public int compare(CurrentAccount currentAccount, CurrentAccount currentAccount2) {
		// TODO Auto-generated method stub
		return (int) (currentAccount.getOverdraft()-currentAccount2.getOverdraft());
	}

}

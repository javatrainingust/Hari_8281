/***
 * ClassName:LoanAccountController
 * 
 * Description:Class for getting all the loan Account details
 * 
 * Date-15-10-2020
 */

package com.training.walmart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.account.model.CurrentAccount;
import com.training.account.model.LoanAccount;
import com.training.accountcollection.service.LoanAccountService;


@Controller
public class LoanAccountController {
	
	/*LoanAccount service class object is created using autowired annotation*/

	@Autowired
	private LoanAccountService loanAccountService;
	
/***
 * Url ending with /showLoanForm calls this method
 * 
 * Create the object for loanaccount and added to model and retuning
 * 
 * addLoanAccount
 * 
 * @param model
 * @return addLoanAccount
 */
	
	@RequestMapping("/showLoanForm")
	public String showLoan(Model model)
	{
	LoanAccount loanAccount = new LoanAccount();
		model.addAttribute("loanKey",loanAccount);
		return "addLoanAccount";
	}
	
	
	/**
	 * url / addloan mapp to this method 
	 * 
	 * call service class method addLoanAccount and then 
	 * 
	 * redirect to loan
	 * 
	 * @param loanAccount
	 * @return loan
	 */
	
	@RequestMapping("/addLoan")
	public String addLoan(@ModelAttribute("loanAccount") LoanAccount loanAccount)
	{
		loanAccountService.addLoanAccount(loanAccount);
	
		
		return "redirect:/Loan" ;
	}
	
	

	/***
	 * Url ending with /Loan mapped to get all deposite method
	 * 
	 * @param model
	 * @return loanDepositeList page in view
	 * getting all the loan account and adding to model 
	 */	
	
	
	
	@RequestMapping("/Loan")
	public String getAllDeposite(Model model)
	{
		System.out.println("Inside the controller getallLoanAccount");
	List<LoanAccount> LoanDepositeList =loanAccountService.getallLoanAccounts();	
		model.addAttribute("loanList",LoanDepositeList);
		return "loanDepositeList";
	}
	

/***
* Method for getting the details of an Loan account by account number and assignig
* 
* to model
*
* @param id -passing through query string
* @param model - Loan model used by loan account view(viewLoanAccount)
* @return - returning view (viewLoanAccount)
*/


	@RequestMapping("/viewLoan")
	public String getLoanAccount(@RequestParam("id") String id,Model model)
	{
		LoanAccount loanAccount = loanAccountService.getLoanAccountByAccountNumber(Integer.parseInt(id));
		
	model.addAttribute("loanAccount", loanAccount);
		return "viewLoanAccount";
	}
	
	/***
	* Method for getting the details of an Loan account by account number and deleting
	* 
	* the account using id
	*
	* @param id -passing through query string
	* 
	* @return - redirecting view (Loan)
	*/


		@RequestMapping("/deleteLoan")
		public String deleteLoanAccount(@RequestParam("id") String id,Model model)
		{
			 loanAccountService.deleteLoanBankAccount(Integer.parseInt(id));
		
			return "redirect:/Loan";

		}
		
		/***
		 * url /updateLoanAccount Mapped to this method 
		 * 
		 * this method call updateExistingLoanAccount using
		 * 
		 * loanBankService and passing the loanObject
		 * 
		 * @param loanAccount
		 * 
		 * @return /Loan
		 */
		
		@RequestMapping("/updateLoanAccount")
		public String updateLoan(@ModelAttribute("loanAccount") LoanAccount loanAccount)
		{
			loanAccountService.updateExistingLoanAccount(loanAccount);
		
			
			return "redirect:/Loan" ;
		}
		

		/***
		 *  /sortLoanAccounByName url maps to this method
		 * 
		 *  this method gets  sorted Loanlist by name 
		 * 
		 * @param model - store Loanlist in model
		 * 
		 * @return loanDepositeList
		 */
		
		@RequestMapping("/sortLoanAccountByName")
		public String  sortLoanAccountByName(Model model)
		{
			List<LoanAccount> loanAccounts = loanAccountService.getAllLoanAccountSortByHolderName();
			
			model.addAttribute("loanList",loanAccounts);
			
			return "loanDepositeList";
		}


		/***
		 *  /sortLoanAccounByOutstanding url maps to this method
		 * 
		 *  this method gets  sorted Loanlist by name 
		 * 
		 * @param model - store Loanlist in model
		 * 
		 * @return loanDepositeList
		 */
		
		
		
		
		@RequestMapping("/sortLoanAccountByOutstanding")
		public String  sortLurrentAccountByBalance(Model model)
		
			{
				List<LoanAccount> loanAccounts = loanAccountService.getAllLoanAccountSortByOutstanding();
				
				model.addAttribute("loanList",loanAccounts);
				
				return "loanDepositeList";
		}
		
}

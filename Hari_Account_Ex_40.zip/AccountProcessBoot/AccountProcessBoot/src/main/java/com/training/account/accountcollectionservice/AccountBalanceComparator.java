/***
 * 
 * ClassName:AccountBalanceComparator
 * 
 * Descriptions:For comparing SavingsBankAccount by Balance amount
 * 
 * Date-07-10-2020
 * 
 */


package com.training.account.accountcollectionservice;

import java.util.Comparator;

import com.training.account.model.SbAccount;

/***
 * This method implementing the Comparator for comparing sb account  and overriding the compare method
 * 
 */

public class AccountBalanceComparator implements Comparator<SbAccount> {

	/***
	 * 
	 * Getting the Sb objects as the arguments and comparing and return assccending order result set
	 * 
	 */
	

	public int compare(SbAccount savingsAccount, SbAccount savingsAccount2) {
		// TODO Auto-generated method stub
		return (int) (savingsAccount.getAmount()-savingsAccount2.getAmount());
	}

}

/**
 * ClassNAme: CurrentAccountTest
 * 
 * Description: Test for CurrentAccountDaoImplementation
 * 
 * Date-08-10-2020
 */

package com.training.account.accountcollectionservice;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.List;

import org.junit.Test;

import com.training.account.model.CurrentAccount;
import com.training.account.model.FixedDeposite;
import com.training.account.model.LoanAccount;

/**
 * Testing 2 methods in Implementation class
 * 
 * 1.AddCurrent Account
 * 
 * 2.UpdateCurrentAccount
 */

public class CurrentAccountAddTest {


    CurrentAccountService accountService = new CurrentAccountService();
	
    /***
     * Adding new Current account using test
     */
    
	public CurrentAccountAddTest() {
		// TODO Auto-generated constructor stub
	
		 
        System.out.println("Adding new Accounts.............");
		
		System.out.println(".............");
		
		accountService.addCurrentAccount(new  CurrentAccount(1001,"Manu",110,500));
		
		accountService.addCurrentAccount( new  CurrentAccount(1000,"Hari",100,1000));
		
		accountService.addCurrentAccount( new  CurrentAccount(1002,"Suku",120,300));
		
		accountService.addCurrentAccount( new  CurrentAccount(1002,"Suku",120,300));
		
		accountService.getallCurrentAccounts();

	
	}
	
	
	/***
	 * Testing Duplicate entry is not possible
	 */
	@Test
	public void testAddCurrentAccount() {
		
		int expectedValue = 1;
		
		int actualValue =2;
	    
		CurrentAccount ca1=new CurrentAccount(1000,"Hari",100,1000);
	    
		accountService.addCurrentAccount(ca1);
	    
		List<CurrentAccount> caTemp=  accountService.getallCurrentAccounts();
	    
		Iterator<CurrentAccount> iterator = caTemp.iterator();
	    
		while(iterator.hasNext())
	    {
	    	CurrentAccount ca2 = iterator.next();
	    	/*Checking by id and getting the occurrence of account*/
	    if(ca1.getAccountNumber()==ca2.getAccountNumber())
	    		{
	    	
	    	       expectedValue = ++expectedValue;
	    		}
	    }
	    
	    
        assertEquals(expectedValue, actualValue);
	}

	/***
	 * Testing Updation in existing records
	 */
	
	@Test
	public void testUpdateExistingCurrentAccount() {
		
		String expected="HariKrishnan";
		
		float expectedAmount=1200.f;
		
		float actualAmount =0.0f;
		
		int expectedSize=3;
		
		int actualSize=0 ;
		
		
	    String actual = null;
	   
	    CurrentAccount ca1=new CurrentAccount(1000,"HariKrishnan",1200,1000);;
	    
	    accountService.updateExistingCurrentAccountAccount(ca1);
	    
	    CurrentAccount ca2=accountService.getCurrentAccountByAccountNumber(1000);
	    
	    actual=ca2.getAccountHolderName();
	    
	    actualAmount=ca2.getAmount();
	    
	    actualSize=accountService.getallCurrentAccounts().size();
	    
	    assertEquals(expected,actual);
	    
	    assertEquals(expectedAmount, actualAmount,0.0f);
	    
	    assertEquals(expectedSize, actualSize);
		
	}

}

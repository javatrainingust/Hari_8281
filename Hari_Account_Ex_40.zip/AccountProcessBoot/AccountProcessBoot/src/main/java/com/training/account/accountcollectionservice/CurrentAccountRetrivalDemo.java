/**
 * ClassName:CurrentAccountRetrivalDemo
 * 
 * Description:MainMethod for Processing  Functionality 
 * 
 * Date-06-10-2020
 * */



package com.training.account.accountcollectionservice;

/***
 * Class contain main method Here the execution of the Current Account starts
 * 
 */
public class CurrentAccountRetrivalDemo {
	
	
	/***
	 * Invoking the methods like getallCurrentAccounts getCurrentAccountByAccountNumber in the current 
	 * 
	 * service class
	 * 
	 *  */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
          CurrentAccountService currentAccountService = new CurrentAccountService();		
          currentAccountService.getallCurrentAccounts();	

        System.out.println("");
		System.out.println("Searching by id..........");
		System.out.println("");
		
	    currentAccountService.getCurrentAccountByAccountNumber(1000);

	}

}

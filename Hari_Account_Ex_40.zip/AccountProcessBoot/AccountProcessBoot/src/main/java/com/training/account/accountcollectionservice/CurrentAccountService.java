/***
 * ClassName:CurrentAccountService
 * 
 * Description:Service Class for the CurrentAccount
 * 
 * Date -06-10-2020
 */


package com.training.account.accountcollectionservice;

import java.util.Collections;
import java.util.Iterator;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.account.dataaccess.CurrentAccountDao;
import com.training.account.dataaccess.CurrentAccountDaoImplementation;
import com.training.account.model.CurrentAccount;
import com.training.account.model.CurrentAccount;
import com.training.account.model.CurrentAccount;

/***
 * This class is used for carry out 3 operation
 * 
 * 1.Getting and displaying all the current account details 
 * 
 * 2.Getting current account details by accountNumber
 * 
 * 3.Delete the current account by AccountNumber
 * 
 * @Service is used for creating Current account service object
 * 
 */

@Service
public class CurrentAccountService {
	
	/*CurrentAccountDao class object is created using autowired annotation*/

	
	@Autowired
   private CurrentAccountDao dao; 

	/**
	 * Constructor for the CurrentAccountService inside the constructor we are creating the object
	 * 
	 * of currentAccount Implementation class
	 * 
	 * */
    
	public CurrentAccountService(){
		
		//dao=new CurrentAccountDaoImplementation();
	
	
	}
	
	/***
	 * Displaying all the Current account Returing the current account list to the 
	 * 
	 * Current account retrieval and testgetallcurrentAccount 
	 *  */
	
	public List<CurrentAccount> getallCurrentAccounts()
	{
		List<CurrentAccount> caccounts= dao.getAllCurrentAccount();
		
		
		/*
		 * Iterator<CurrentAccount> iterator = caccounts.iterator();
		 * 
		 * while(iterator.hasNext()) { CurrentAccount ca=iterator.next();
		 * 
		 * 
		 * System.out.println("");
		 * 
		 * System.out.println("Name of Account Holder           -"+ca.
		 * getAccountHolderName());
		 * 
		 * System.out.println("Account number of Account Holder -"+ca.getAccountNumber()
		 * );
		 * 
		 * 
		 * System.out.println("Amount of Account Holder          -"+ca.getAmount());
		 * 
		 * System.out.println("OverDraft of Account Holder          -"+ca.getOverdraft()
		 * );
		 * 
		 * }
		 */
		
	
		
		return caccounts;
	}
	
	/***
	 * Displaying the Account holder details by passing the account number and return the 
	 * 
	 * CAccount object to the current account retrival class and the testgetCurrentAccountByAccountNumber
	 * 
	 */

	public CurrentAccount getCurrentAccountByAccountNumber(int accountNumber)
	{
		CurrentAccount currentAccount=dao.getCurrentAccountByAccountNumber(accountNumber);
		
		
		System.out.println("");
		
		System.out.println("Name of Account Holder           -"+currentAccount.getAccountHolderName());
		
		System.out.println("Account number of Account Holder -"+currentAccount.getAccountNumber());
		
		
		System.out.println("Amount of Account Holder          -"+currentAccount.getAmount());
		
		System.out.println("OverDraft of Account Holder          -"+currentAccount.getOverdraft());
	    
		
		
		return currentAccount;
	}
	
	/**
	 * Deleting the Current account details by using the accountnumber*/
	
	public void deleteCurrentAccountByAccountNumber(int accountNumber)
	{
		dao.deleteCurrentAccountkByAccountNumber(accountNumber);
		
		
	}
	
	
	/***
	 * Method for getting sorted list of current account  by name,Returning the sorted set 
	 * 
	 * and displaying the sorted list (Using -Stream)
	 * 
	 */
	public List<CurrentAccount> getAllCurrentAccountSortByHolderName()
	{
		List<CurrentAccount> caAccountsList= dao.getAllCurrentAccount();
		
		//Collections.sort(caAccounts);
		
    Stream<CurrentAccount> CurrentAccountsStream = caAccountsList.stream();
	    
	    Stream<CurrentAccount> currentAccountSortedStream= CurrentAccountsStream.sorted();
	    
	    List<CurrentAccount> caAccounts = currentAccountSortedStream.collect(Collectors.toList());
		
        
		Iterator<CurrentAccount> iterator = caAccounts.iterator();
		
		while(iterator.hasNext())
		{
			CurrentAccount currentAccount=iterator.next();
			
			
			System.out.println("");
		
			System.out.println("Name of Account Holder           -"+currentAccount.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+currentAccount.getAccountNumber());
			
			
			System.out.println("Amount of Account Holder          -"+currentAccount.getAmount());
			
			System.out.println("OverDraft of Account Holder          -"+currentAccount.getOverdraft());
			
		}
		return caAccounts;
	}
	
	/***
	 * Method for getting sorted list of current account by Holder balance amount ,Returning the sorted set by 
	 * 
	 * and displaying the sorted list (Using -Stream)
	 * 
	 */
	
	public List<CurrentAccount> getAllCurrentAccountSortByAccountOverDraft()
	{

		List<CurrentAccount> caAccountList= dao.getAllCurrentAccount();
		
		//Collections.sort(caAccounts,new CurrentAccountOverdraftComparator())



		Stream<CurrentAccount> CurrentAccountSalaryStream = caAccountList.stream();


		Stream<CurrentAccount> CurrentAccountSalarySortStream = CurrentAccountSalaryStream.sorted(new CurrentAccountOverdraftComparator());;


		List<CurrentAccount> caAccounts = CurrentAccountSalarySortStream.collect(Collectors.toList());



		Iterator<CurrentAccount> iterator = caAccounts.iterator();
		
		while(iterator.hasNext())
		{
			CurrentAccount currentAccount=iterator.next();
			
			
			System.out.println("");
		
			System.out.println("Name of Account Holder           -"+currentAccount.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+currentAccount.getAccountNumber());
			
			
			System.out.println("Amount of Account Holder          -"+currentAccount.getAmount());
			
			System.out.println("Overdraft of Holder          -"+currentAccount.getOverdraft());
			
		}
		return caAccounts;
	}
	

	/***
	 * 
	 * Displaying the added CurrentAccount is already present or not
	 * 
	 * 	 */

	public boolean addCurrentAccount(CurrentAccount currentAccount)
	{
		boolean isAdded= dao.addCurrentAccount(currentAccount);
		
		if(isAdded)
		{
			System.out.println("CurrentAccount added Successfully");
			
		}
		
		else
		{
		
			System.out.println("Duplicate Current Account");
			
		}
		
		return isAdded;
	}
	/***
	 * Updating an Existing Current  Account
	 */
	
	public void updateExistingCurrentAccountAccount(CurrentAccount currentAccount)
	{
		
		dao.updateExistingCurrentAccount(currentAccount);
		
	}
	
	

}

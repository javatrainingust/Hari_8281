/**
 * ClassName:FixedDepositeDeleteDemo
 * 
 * Description:MainMethod for Processing Delete Functionality 
 * 
 * Date-06-10-2020
 * */

package com.training.account.accountcollectionservice;

/***
 * Contains the main method and this class initiate the delete process of fdAccount
 * 
 */


public class FixedDepositeDeleteDemo {

	
	/***
	 * Creating the fdService Class object for callig delete methods and getallfixeddeposite methods
	 * 
	 * */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FixedDepositeService service = new FixedDepositeService();
		
		service.getAllFixedDposites();
		
		service.deleteFixedDepositeAccount(1001);
		
		System.out.println("After Delete");
		
		service.getAllFixedDposites();
	}

}

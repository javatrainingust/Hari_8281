/**
 * ClassName:FixedDepositeRetrivalDemo
 * 
 * Description:MainMethod for Processing Retrival Functionality 
 * 
 * Date-06-10-2020
 * */

package com.training.account.accountcollectionservice;

/**
 * Class contains main method the execution of fdAccount starts here */

public class FixedDepositeRetrivalDemo {

	/**
	 * Creating the fdservice class object for calling the methods in fdservice class
	 * 
	 * Calling -getallfdaccount and getaccountbyid
	 *  
	 * */
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FixedDepositeService service = new FixedDepositeService();
		
		service.getAllFixedDposites();
		System.out.println("");
		System.out.println("Searching by id..........");
		System.out.println("");
		
		service.getFixedDepositeByAccountNumber(1000);

	}

}

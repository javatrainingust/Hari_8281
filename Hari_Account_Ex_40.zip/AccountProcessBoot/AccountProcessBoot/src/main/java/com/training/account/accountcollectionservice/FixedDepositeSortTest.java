/***
 * ClassName:FixedDepositeSortTest
 * 
 * Description: Testing name and holderAmount sorting
 * 
 * Date - 06-10-2020
 * 
 */




package com.training.account.accountcollectionservice;

import static org.junit.Assert.*;

import java.security.Provider.Service;
import java.util.List;

import org.junit.Test;

import com.training.account.model.FixedDeposite;


/***
 * Test Class for testing getAllFixedDepositeSortByHolderName,getAllFixedDepositeSortByAccountBalance
 * 
 * methods both resides in fdservice class 
 * 
 */


public class FixedDepositeSortTest {

	FixedDepositeService service = new FixedDepositeService();
	 List<FixedDeposite> fixedDeposite;
	@Test
	
	/***
	 *  2 Testing
	 *  
	 *  1- By size of FdList
	 *  
	 *  2- By First name comparison
	 */
	
	public void testGetAllFixedDepositeSortByHolderName() {
		
		String expectedValue="Hari";
        fixedDeposite	=service.getAllFixedDepositeSortByHolderName();
		String actualValue = fixedDeposite.get(0).getAccountHolderName();
        assertEquals(expectedValue, actualValue);
        assertEquals(3, fixedDeposite.size());
		
	}

	@Test
	

	/***
	 *  2 Testing 
	 *  
	 *  1-By size of FdList
	 *  
	 *  2-By First amount comparison
	 */
	public void testGetAllFixedDepositeSortByAccountBalance() {

		float expected=100.f;
		  fixedDeposite	=service.getAllFixedDepositeSortByAccountBalance();
			float actual = fixedDeposite.get(0).getAmount();
			assertEquals(expected, actual,0.0f);
	        assertEquals(3, fixedDeposite.size());
		
	}

}

/***
 * ClassName:LoanAccountAddTest
 * 
 * Description:Testing methods like add and update in 0LoanAccountdaoImmplementation class
 * 
 * date  08-10-2020
 * 
 */


package com.training.account.accountcollectionservice;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.List;

import org.junit.Test;

import com.training.account.model.FixedDeposite;
import com.training.account.model.LoanAccount;

/**
 * 
 * Testing addLoanAccount and Update existing loan account
 */


public class LoanAccountAddTest {

    LoanAccountService accountService = new LoanAccountService();	
	
    /**
     * Adding account to list  for testing
     * 
     */
	public LoanAccountAddTest() {
	
		// TODO Auto-generated constructor stub


			 
     System.out.println("Adding new Accounts.............");
		
		System.out.println(".............");
		
		accountService.addLoanAccount(new  LoanAccount(1001,"Manu",110,500));
		
		accountService.addLoanAccount( new  LoanAccount(1000,"Hari",100,1000));
		
		accountService.addLoanAccount( new  LoanAccount(1002,"Suku",120,300));
		
		accountService.addLoanAccount( new  LoanAccount(1002,"Suku",120,300));
	
	
	}
	
	/***
	 * Testing the loan account for duplicates
	 * 
	 */
	
	@Test
	public void testAddLoanAccount() {

		int expectedValue = 1;
		
		int actualValue =2;
	    
		LoanAccount la1=new LoanAccount(1002,"Suku",120,300);
	    
		accountService.addLoanAccount(la1);
	    
		List<LoanAccount> laTemp=  accountService.getallLoanAccounts();
	    
		Iterator<LoanAccount> iterator = laTemp.iterator();
	    
		while(iterator.hasNext())
	    {
	    	LoanAccount la2 = iterator.next();
	    	/*Checking by id and getting the occurrence of account*/

	    if(la1.getAccountNumber()==la2.getAccountNumber())
	    		{
	    	
	    	       expectedValue = ++expectedValue;
	    		}
	    }
	    
	    
        assertEquals(expectedValue, actualValue);
	}
	
	/***
	 * Testing weather updation done correctly
	 */

    @Test
	public void testUpdateExistingLoanAccount() {
		
		String expected="HariKrishnan";
		
				float expectedAmount=1200.f;
		
				float actualAmount =0.0f;
		
				int expectedSize=3;
			
				int actualSize=0 ;
		
		
				String actual = null;
		
				LoanAccount la1=new LoanAccount(1000,"HariKrishnan",1200,1000);;
	   
				accountService.updateExistingLoanAccount(la1);
	  
				LoanAccount la2=accountService.getLoanAccountByAccountNumber(1000);
	
				actual=la2.getAccountHolderName();
	  
				actualAmount=la2.getAmount();
	   
				actualSize=accountService.getallLoanAccounts().size();
	    
				assertEquals(expected,actual);
	    
				assertEquals(expectedAmount, actualAmount,0.0f);
	
				assertEquals(expectedSize, actualSize);
		
	}

}

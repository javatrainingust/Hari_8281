/**
 * ClassName:LoanAccountRetrivalDemo 
 * 
 * Description:MainMethod for calling relavent methods 
 * 
 * Date-06-10-2020
 * */



package com.training.account.accountcollectionservice;

/***
 * This class Contains main method and is used for Create the service class obj for loan account for
 * 
 *calling the Service class methods for listing and listing bu account id
 * 
 */
public class LoanAccountRetrivalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LoanAccountService loanAccountService = new LoanAccountService();
		loanAccountService.getallLoanAccounts();
		
		System.out.println("");
		System.out.println("Searching by id..........");
		System.out.println("");
		
	     loanAccountService.getLoanAccountByAccountNumber(1000);

	}

}

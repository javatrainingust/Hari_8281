/***
 * ClassName:SavingBankRetrivalDemo
 * 
 * Description:Main method for calling methods in service class
 * 
 * Date -06-10-2020
 * 
 */

package com.training.account.accountcollectionservice;



/***
 * Main method for Calling Operations like listing and searching Sb accounts
 *
 */

public class SavingsBankRetrivalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	SavingsBankService savingsBankService = new SavingsBankService();
		
		savingsBankService.getallSavingsBankDeposite();
		System.out.println("");
		System.out.println("Searching by id..........");
		System.out.println("");
		
	 savingsBankService.getSavingsBankByAccountNumber(100);


	}

}


/***
 * ClassName:WithDrawingMoneyFromSb
 * 
 * Description:Withdrawal operation
 * 
 * Date:09-10-2020
 * 
 */



package com.training.account.accountcollectionservice;

import com.training.account.balanceInSufficientExeption.InsufficientBalanceException;
import com.training.account.model.SbAccount;


/***
 * 
 * Withdrawing Amount from an account process initiating from this class
 */


public class SbAccountMoneyRetrival {

	/***
	 *Main Method for withdrawal functionality 
	 *
	 * Execution starts here
	 *
	 *	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SavingsBankService service = new SavingsBankService();
		
		
		SbAccount sbAccount=service.getSavingsBankByAccountNumber(100);
		
		/*try block*/
	
		try
		{
			
		/*Call to withdrawal method in SbAccount Class*/
			
		sbAccount.withdrawMoney(150);
		
		}
		
		/*Catch block*/
		
		catch (InsufficientBalanceException e) {

			System.out.println("You have "+sbAccount.getAmount()+" in your account "+e);
		}
		
	}

}

/***
 * ClassName:InsufficientBalanceException
 * 
 * 
 * Description:Handiling insufficient Balance withdrawal
 * 
 * 
 * Date - 09-10-2020
 * 
 */





package com.training.account.balanceInSufficientExeption;


/***
 * Extending Exception for writing user defined checked exception
 * 
 */
public class InsufficientBalanceException extends Exception {
	
	
	float balance;
	
	
	/***
	 * Constructor receiving balance from withdrawal method of sb account
	 * 
	 * @param balance
	 */
	
	public InsufficientBalanceException(float balance)
	{
		
		this.balance=balance;
		
	}
	/***
	 * Overriding to String method for printing
	 * 
	 */
	
	public String toString()
	{
		return "you donot not  have enough balance you tried for "+balance+" Amount";
	}

}

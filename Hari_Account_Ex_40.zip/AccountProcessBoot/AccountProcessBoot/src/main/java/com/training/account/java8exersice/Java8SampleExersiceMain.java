/***
 * ClassName:Java8SampleExersiceMain
 * 
 * Description:Sample exercise for predicate , functional,consumer,supplier
 * 
 * Date-08-10-2020
 * 
 */

package com.training.account.java8exersice;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.Predicate;

import org.junit.Test;

import com.training.account.model.FixedDeposite;


/***
 * 
 *Implementing Predicate,function,consumer,supplier with different business logic
 */

public class Java8SampleExersiceMain {

	/***
	 * 
	 * Main method execution starts here for predicate,function,consumer,supplier
	 * */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FixedDeposite fd = new FixedDeposite();
		fd.setAccountHolderName("H");
		fd.setAmount(1000);
		
		/***
		 * Returning Random number using supplier Interface with out input 
		 * 
		 * 
		 */
		
		/*Random num generation by multiplying with 10000*/
		
		Supplier randumNumberSupplier= () -> Math.random()*10000;
		
		System.out.println("1) Random Number Using Supplier Interface");
		
		System.out.println("****************************************");
		
		System.out.println("");
		
		System.out.println("Random Number -"+randumNumberSupplier.get());
		
		System.out.println("****************************************");
		
		
		
		/**
		 * Using Consumer Interface going to return Uppercase version of input string
		 */
		
		Consumer<String> upperCaseString = (s) -> System.out.println( "lower case " +s+   " to  UpperCase   "+s.toUpperCase());
		
		System.out.println("");

		System.out.println("2) Lower Case to Upper Case Coversion");

		System.out.println("****************************************");
		
		
		upperCaseString.accept("hari");
		
		
		
		/***
		 * Check weather the  input value is greater than 50 or not using predicate and  predicate will return true 
		 * 
		 * or false 
		 */
		
         Predicate<FixedDeposite> isGreaterThanFifty = (f) -> f.getAccountHolderName().equals("k");
        

 		System.out.println("");

 		System.out.println("3) True Or False");

 		System.out.println("****************************************");
         
 		System.out.println("Number is greater than 50  " +isGreaterThanFifty.test(fd));
        
 		
 		/***
 		 * Converting Lowercase to UpperCase using function and giving input string to function using apply
 		 * 
 		 *  
 		 * method and returning a string  and printing it.
 		 */
 		
 		Function <String,String> lowerToUpper = (s) -> s.toUpperCase();
 		
 		System.out.println("");

 		System.out.println("4) Lower to Upper");

 		System.out.println("****************************************");
 		System.out.println("Upper Case Conversion   " + lowerToUpper.apply("hari"));
 		
	}

}

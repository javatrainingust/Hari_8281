package com.training.account.model;
/**
 * Classname:LoanAccount
 * 
 * 
 * Description:Its one of the sub class for Account subclasses.
 * 
 * Date:30/09/2020
 * */



import com.training.account.util.IntrestCalculator;



/**
 * The class used for model Account class and implementing Comparable
 */


public class LoanAccount extends Account implements Comparable<LoanAccount>{
	int emi;
	float tenure =5;
	float outstandingAmount;
	
	
	public float getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(float outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public int getEmi() {
		return emi;
	}
	
	public LoanAccount()
	{
		
	}
	
	public LoanAccount(int accountnumber,String holdername,float amount,float outstandingAmount) {
		super(accountnumber,holdername,amount);
		this.outstandingAmount=outstandingAmount;
	}

	
	/**
	 * Accessory Method for Emi
	 */
	
	
	public void setEmi(int emiparameter) {
		emi = emiparameter;
	}
	
	
	/**
	 * Accessor Method for Tenure of loan
	 */
	
	public float getTenure() {
		return tenure;
	}
	
	/**
	 * Accessory Method for tenure of loan
	 */
	
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	
	
	/**
	 *  Method for Calculating Emi and printing emi Parameter comming from Account service class
	 */
	
	public void emiCalculation(float balance) {
		
		this.emi=(int) (balance/tenure);
		
		System.out.println("Emi"+emi);
		
	}

	/***
	 * Overriding the Compareto method in comparable interface for sorting Loanaccount by holder name
	 * 
	 */
	
	public int compareTo(LoanAccount loanAccount) {
		// TODO Auto-generated method stub
		return this.accountHolderName.compareTo(loanAccount.accountHolderName);
	}

}

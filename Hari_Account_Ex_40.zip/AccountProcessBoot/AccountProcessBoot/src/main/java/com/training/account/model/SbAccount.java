/**
 * Classname:SbAccount
 * 
 * 
 * Description:Its one of the sub class for Account subclasses.Handiling SavingAccount of a customer
 * 
 * Date:30/09/2020
 * */


package com.training.account.model;

import com.training.account.balanceInSufficientExeption.InsufficientBalanceException;
import com.training.account.util.ICalculator;
import com.training.account.util.IntrestCalculator;


/**
 * The class used for model SbAccount class,it is inheriting from Account class.
 * it is inheriting from Account class and implementing Comparable
 */


public class SbAccount extends Account implements Comparable<SbAccount> {
	
	float rate=.5f;
	
	
	
	


	/**
	 * Default SbAccount Constructor
	 */

	
	public SbAccount()
	{
		System.out.println("Sb Base Class");
		
	}
	
	
	/**
	 * Parameterised constructor calling from Serviceimplementingclass
	 */
	
	
	
	public SbAccount(int accountnumber,String holdername,float amount)
	{
		super(accountnumber,holdername,amount);
		//this.rate=rateofintrest;
	//	System.out.println("Holdername - "+ holdername);
		//System.out.println("Holdername via Baseclass  "+getAccountHolderName());
	}

	
	/**
	 * Overriding method of base class
	 */
	
	public void calculateIntreast(float Amt,ICalculator calculator) {
		System.out.println(" Inside Sb Amount Passing Amount "+Amt);
		 float Interest = calculator.calculateDepositeIntrest(Amt,1,rate);
	
		
	}
	
	/***
	 * 
	 * @param Money
	 * @throws InsufficientBalanceException
	 * 
	 * This method is for doing withdrawal logical operation in an Sb Account
	 * 
	 */
	
	public void withdrawMoney(float Money) throws InsufficientBalanceException {
		
		if(Money > this.getAmount())
		{
			/*Class to InsufficientBalanceConstructor*/
			throw new InsufficientBalanceException(Money);
		}
		else
		{
			/*Withdrawing process*/
			this.setAmount(this.getAmount() -Money);
			
			System.out.println("New Balance = "+ this.getAmount());
		}
		
		

	}
	
	
	
	

	/***
	 * Overriding the Compareto method in comparable interface for sorting SbAccount by holder name
	 * 
	 */

	public int compareTo(SbAccount savingsAccount) {
		// TODO Auto-generated method stub
		return this.accountHolderName.compareTo(savingsAccount.getAccountHolderName());
	}
	
	

}

package com.training.account.serviceImplemetingConstructors;

import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;

public class ServiceConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SbAccount sb= new SbAccount(101,"Remesh",200);
		FixedDeposite fd= new FixedDeposite(100,"Babu",1000,6);

	}

}

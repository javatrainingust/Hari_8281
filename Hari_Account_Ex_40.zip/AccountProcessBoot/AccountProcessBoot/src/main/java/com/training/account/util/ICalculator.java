/**
 * Classname:ICalculator
 * 
 * Description:Its an interface for calculating Intrest for ICalculator Premium and Icalculator Interest and implements by both sb and fd.
 *  
 * Date:30/09/2020
 * */




package com.training.account.util;

public interface ICalculator {
	
/*Method declaration for Sb Account*/	
 
 float calculateDepositeIntrest(float Amount,int year,float R);
 
 /*Method declaration for Fd Account*/
 
 float calculateDepositeIntrest(float Amount,int year);

}

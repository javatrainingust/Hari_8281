/**
 * ClassName:InterestCalculatorTest
 * 
 * Description:For testing the Interest calculate method
 * 
 * Date-01-10-2020
 */




package com.training.account.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.training.account.model.SbAccount;

public class InterestCalculatorTest {

	IntrestCalculator Ic= new IntrestCalculator();
	
	
	/**
	 * Method for testing Sb Interest
	 * 
	 * */
	
	@Test
	public void testCalculateDepositeIntrestFloatIntFloat() {
		


		float expectedInterest=50;
	   		
		float actualInterest=Ic.calculateDepositeIntrest(1000,1,.05f);
		
		assertEquals(expectedInterest, actualInterest,0.0f);
	}
	
	
	/**
	 * Method for testing Fd Interest
	 * 
	 */

	
	@Test
	public void testCalculateDepositeIntrestFloatInt() {
	

		float expectedInterest=70;
	   		
		float actualInterest=Ic.calculateDepositeIntrest(1000,1);
		
		assertEquals(expectedInterest, actualInterest,0.0f);
	
	
	}

}

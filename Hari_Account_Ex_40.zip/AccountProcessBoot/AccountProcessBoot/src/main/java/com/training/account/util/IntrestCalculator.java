/**
 * Classname:InterestCalculator 
 * 
 * Description:Class for calculating Intrerest.Overloading is done using calculateDeposite methods.
 * 
 * Date:30/09/2020
 * */



package com.training.account.util;


public class IntrestCalculator implements ICalculator{
	
	float rate;
	
	/**
	 * Implementing Method in interface ICalculator for calculating Sb interest
	 * 
	 * 	  call coming from GeneralService class
	 */
	
	public float calculateDepositeIntrest(float Amount,int year,float R) {
		
		float Intrest=Amount*year*R;
		System.out.println(" Intrest processing");
		System.out.println("********************");
		System.out.println("Sb Account Normal Intrest -" + Intrest);
		return Intrest;
	}

	
	/**Implementing Method in interface ICalculator and,
	 * 
	 *  Using that calculating FD interest
	 *  
	 *  call coming from Account class and GeneralService class
	 */
	
	
	public float calculateDepositeIntrest(float Amount,int year) {
		rate=.07f;
		System.out.println(Amount);
		System.out.println(year);
		float Intrest=Amount*year*rate;
		System.out.println(" Intrest processing");
		System.out.println("********************");
		System.out.println("Fd Account Normal Intrest -" + Intrest);
		return Intrest;
		
	}

}

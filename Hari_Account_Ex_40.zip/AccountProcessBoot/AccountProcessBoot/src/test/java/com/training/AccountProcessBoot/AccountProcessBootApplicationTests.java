package com.training.AccountProcessBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountProcessBootApplicationTests {

	@Test
	void contextLoads() {
	}

}

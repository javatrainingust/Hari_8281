/***
 * ClassName : SbAccoutSortDemo
 * 
 * Description:Main method for sorting SbAccount by holdername and Balance Amount
 * 
 * Date-07-10-2020
 */


package com.training.accountcollection.service;

/***
 * Main method where the execution started for sorting the sb account by holders name
 * 
 * Calling sbservice class methods using the Service object and the methods are getAllSbAccountSortByHolderName
 * 
 * getAllSbAccountSortByAccountBalance
 * 
 */



public class SbAccoutSortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SavingsBankService service = new SavingsBankService();
		
		System.out.println("List Before Sorting");
		
		service.getallSavingsBankDeposite();
		
        System.out.println("");
		
		System.out.println("List After Sorting");
		
		System.out.println("-------------");
		

		service.getAllSbAccountSortByHolderName();
		
		
	    System.out.println("");
		
		System.out.println("Sorting by Amount");
		

        System.out.println("--------------------");
		
		 service.getAllSbAccountSortByAccountBalance();
		
		
	}

}

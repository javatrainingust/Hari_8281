/***
 * ClassName:SbAccountController
 * 
 * Description:Class for getting all the savings bank details
 * 
 * Date-15-10-2020
 */
package com.training.walmart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.account.model.SbAccount;
import com.training.accountcollection.service.SavingsBankService;
/***
 * 
 * Class annotated with controller spring create SbAccountController class
 * 
 * 
 * 
 */
@Controller
public class SbAccountController {
	/*SavingsBank service class object is created using autowired annotation*/
	@Autowired
	private SavingsBankService savingsBankService;

	/***
	 * Url ending with /Saving mapped to get all deposite method
	 * 
	 * @param model
	 * @return sbDepositeList page in view
	 * getting all the savings account and adding to model 
	 */
	@RequestMapping("/Saving")
	public String getAllDeposite(Model model)
	{
		
		System.out.println("Inside the controller getallSavings account");
	
		List<SbAccount> savingDepositeList =savingsBankService.getallSavingsBankDeposite();	
		
		model.addAttribute("sbList",savingDepositeList);
		
		return "sbDepositeList";
	}


}

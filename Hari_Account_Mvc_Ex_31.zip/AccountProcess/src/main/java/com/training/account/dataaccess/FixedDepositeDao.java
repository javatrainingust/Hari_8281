/**
 * InterfaceName: FixedDepositeDao 
 * 
 * Description:Interface for adding,retrieving,delete details in FdAccount
 * 
 * Date -06-10-2020
 */




package com.training.account.dataaccess;

import java.util.List;

import com.training.account.model.FixedDeposite;

/***
 * 
 * Interface for the FixedDeposite dao operations and is implemented by FixedDepositedaoImplementation
 */

public interface FixedDepositeDao {
	
	
	/*Method declaration for getting all the fd accounts and is implemented in FixedDepositeDaoImplementation*/

	public List<FixedDeposite> getAllFixedDeposites();
	
	
	/*Method declaration for getting  the fd account by accountnumber and is implemented in FixedDepositeDaoImplementation*/

	public FixedDeposite getFixedDepositeByAccountNumber(int accountNumber);
	
	
	/*Method declaration for deleting  the fd account by accountnumber and is implemented in FixedDepositeDaoImplementation*/

	public void deleteFixedDepositeByAccountNumber(int accountNumber);
	
	
	/* Adding Fixed Deposite and then cheking for duplicate*/
	
	public boolean addFixedDepositeAccount(FixedDeposite fixedDeposite);
	
	/*Updating an existing Fd Account*/
	
	public void updateExistingFixedDepositeAccount(FixedDeposite fixedDeposite);
	

}

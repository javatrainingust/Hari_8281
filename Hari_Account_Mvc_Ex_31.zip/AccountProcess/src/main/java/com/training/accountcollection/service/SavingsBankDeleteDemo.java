/***
 * ClassName:SavingBankDeleteDemo
 * 
 * Description:Main method for calling Delete method in service class
 * 
 * Date -06-10-2020
 * 
 */



package com.training.accountcollection.service;

/***
 * Class contains Main method for initiating delete operation and searching Sb accounts
 *
 */


public class SavingsBankDeleteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SavingsBankService savingsBankService = new SavingsBankService();
		

		savingsBankService.getallSavingsBankDeposite();
	

		savingsBankService.deleteSavingsBankAccount(100);
		
		System.out.println("After Delete");
		savingsBankService.getallSavingsBankDeposite();
			

	}

}

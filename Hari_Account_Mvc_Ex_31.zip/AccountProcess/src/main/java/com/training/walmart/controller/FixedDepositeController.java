/***
 * ClassName:FixedDepositeController
 * 
 * Description:Class for getting all the fixedDeposite details
 * 
 * Date-15-10-2020
 */

package com.training.walmart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.account.model.FixedDeposite;
import com.training.accountcollection.service.FixedDepositeService;

@Controller
public class FixedDepositeController {
	
	/*FixedDeposite service class object is created using autowired annotation*/
	
	@Autowired
	private FixedDepositeService fdservice;

	/***
	 * Url ending with /fixeddeposite mapped to get all deposite method
	 * 
	 * @param model
	 * @return fixedDepositeList page in view
	 * getting all the fd account and adding to model 
	 */
	
	@RequestMapping("/fixeddeposite")
	public String getAllDeposite(Model model)
	{
		System.out.println("Inside the controller getallFixedDeposite");
	List<FixedDeposite> fixedDepositeList =fdservice.getAllFixedDposites();	
		model.addAttribute("FdList",fixedDepositeList);
		
		return "fixedDepositeList";
	}
}

/***
 * ClassName:LoanAccountController
 * 
 * Description:Class for getting all the loan Account details
 * 
 * Date-15-10-2020
 */

package com.training.walmart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.account.model.LoanAccount;
import com.training.accountcollection.service.LoanAccountService;


@Controller
public class LoanAccountController {
	
	/*LoanAccount service class object is created using autowired annotation*/

	@Autowired
	private LoanAccountService loanAccountService;
	

	/***
	 * Url ending with /Loan mapped to get all deposite method
	 * 
	 * @param model
	 * @return loanDepositeList page in view
	 * getting all the loan account and adding to model 
	 */
	@RequestMapping("/Loan")
	public String getAllDeposite(Model model)
	{
		System.out.println("Inside the controller getallLoanAccount");
	List<LoanAccount> LoanDepositeList =loanAccountService.getallLoanAccounts();	
		model.addAttribute("loanList",LoanDepositeList);
		return "loanDepositeList";
	}

}

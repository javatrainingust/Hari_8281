/***
 * ClassName : LoanAccountMapper
 * 
 * Descriptions:This is the loanmapper class 
 * 
 * Date:24-10-2020
 */


package com.training.account.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.account.model.LoanAccount;


/***
 * 
 *This method  contain the mapRow method implemented from the rowmapper Interface
 *
 */


public class LoanAccountMapper implements RowMapper<LoanAccount>{

	/***
	 * This method is to convert the result set to object and returning the loanAccount object
	 */
	@Override
	public LoanAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		LoanAccount loanAccount = new LoanAccount();
		
		loanAccount.setAccountNumber(rs.getInt("accountNumber"));
		
		loanAccount.setAccountHolderName(rs.getString("holderName"));
		
		loanAccount.setAmount(rs.getFloat("amount"));
		
		loanAccount.setOutstandingAmount(rs.getFloat("outstandingAmount"));
		
		return loanAccount;
	}

}

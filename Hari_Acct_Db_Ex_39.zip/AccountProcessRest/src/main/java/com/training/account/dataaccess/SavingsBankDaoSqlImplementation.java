/***
 * ClassName:SavingsBankDaoSqlImplementation
 * 
 * Description:This is the database implementation SavingBank
 * 
 * Date-24-10-2020
 */



package com.training.account.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.account.model.SbAccount;
/***
 * This method implements the SavingsBankDao and all the methods in Dao are implemented in this method 
 */
@Repository
public class SavingsBankDaoSqlImplementation implements SavingsBankDao {

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;
	/***
	 * DataSource Object creation and passing the datasource object created in bean to Jdbc template 
	 * 
	 * for establishing the connection	
	 * @param dataSource
	 */
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}

	/***
	 * Retrieving all the saving bank account in database and return as a list
	 */
	
	@Override
	public List<SbAccount> getAllSavingsBankDeposite() {
		// TODO Auto-generated method stub
		
		String SQL = "select * from sbaccount";
	      List <SbAccount> sbAccounts= jdbcTemplateObject.query(SQL, new SbMapper());
		
		return sbAccounts;
		
	}
	
	/***
	 * Retrieving the BankDetails by account number and returning it
	 */

	@Override
	public SbAccount getSavingsBankByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM sbaccount where accountNumber = ?" ;
		
		SbAccount sbAccount = (SbAccount) jdbcTemplateObject.queryForObject(sql, new Object[] {accountNumber}, new SbMapper());
		return sbAccount;
	}
	
	/***
	 * 
	 * Deleting the savingbank account for db
	 */

	@Override
	public void deleteSavingsBankByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		
		String sql= "delete from sbaccount where accountNumber='"+accountNumber+"' ";
		jdbcTemplateObject.update(sql);

	}
	
	/***
	 * Adding Saving bank account to db
	 */

	@Override
	public boolean addSavingsAccount(SbAccount sbAccount) {
		// TODO Auto-generated method stub
		
		String sql = "INSERT INTO sbaccount"+
		             "(accountNumber,holderName,amount) VALUES (?,?,?)";
		
		jdbcTemplateObject.update(sql,new Object[] {sbAccount.getAccountNumber(),sbAccount.getAccountHolderName(),sbAccount.getAmount()});
		return true;
	}

	
	/***
	 * Updating the saving bank account in db
	 */
	@Override
	public void updateExistingSavingsAccount(SbAccount sbAccount) {
		// TODO Auto-generated method stub
		
		String query="update sbaccount set holderName='"+sbAccount.getAccountHolderName()+"',amount='"+sbAccount.getAmount()+"' where accountNumber='"+sbAccount.getAccountNumber()+"' ";

		jdbcTemplateObject.update(query);
	}

}

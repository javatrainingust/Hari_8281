package com.training.account.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoanAccountTest {

	@Test
	public void testEmiCalculation() {
		
		float expectedValue=200;
		
		float delta=.0f;
		
		LoanAccount loanAccount = new LoanAccount();
		
		loanAccount.emiCalculation(1000);
		
		float actualValue=loanAccount.getEmi();
		
		assertEquals(expectedValue, actualValue,delta);
	}

}

/***
 * ClassName:LoanAccountSortTest 
 * 
 * Description: Testing name and holderAmount sorting
 * 
 * Date - 07-10-2020
 * 
 */







package com.training.accountcollection.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.training.account.model.FixedDeposite;
import com.training.account.model.LoanAccount;
/***
 * Test Class for testing GetAllLoanAccountSortByHolderName,GetAllLoanAccountSortByOutstanding
 * 
 * methods both resides in service class
 * 
 */




public class LoanAccountSortTest {


	LoanAccountService service = new LoanAccountService();
	 List<LoanAccount> loanAccounts;
	
	
	/***
	 *  2 Testing
	 *  
	 *  1 by size of LoanAccountList
	 *  
	 *  2  by First name comparison
	 */
	
	@Test
	public void testGetAllLoanAccountSortByHolderName() {
		
		
		String expectedValue="Hari";
        loanAccounts	=service.getAllLoanAccountSortByHolderName();
		String actualValue = loanAccounts.get(0).getAccountHolderName();
        assertEquals(expectedValue, actualValue);
        assertEquals(3, loanAccounts.size());
		
		
	
	}
	

	/***
	 *  2 Testing
	 *  
	 *  1 by size of LoanAcccountList
	 *  
	 *  2 by First outstandingamount comparison
	 */

	@Test
	public void testGetAllLoanAccountSortByOutstanding() {
		
		float expected=1000.f;
		  loanAccounts	=service.getAllLoanAccountSortByOutstanding();
			float actual = loanAccounts.get(0).getOutstandingAmount();
			assertEquals(expected, actual,0.0f);
	        assertEquals(3, loanAccounts.size());
		
		
	}

}

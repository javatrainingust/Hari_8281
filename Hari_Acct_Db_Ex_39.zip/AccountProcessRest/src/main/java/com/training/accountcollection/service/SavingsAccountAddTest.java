/***
 * Classname:SavingsAccountTest
 * 
 * Description:Testing Implemented methods for add and update in SavingAccountdaoImp class
 * 
 * Date 08-10-2020
 */

package com.training.accountcollection.service;

import static org.junit.Assert.*;

import java.security.Provider.Service;
import java.util.Iterator;
import java.util.List;

import org.junit.Test;

import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;

/**
 * 
 * Testing class for 2 methods in SavingBankDaoImplementationclass(AddSb and updateSb) 
 */

public class SavingsAccountAddTest {
	

	SavingsBankService savingsBankService = new SavingsBankService();
	 
	/***
	 * Adding sbList using Constructors 
	 */
	
	public SavingsAccountAddTest() {
		// TODO Auto-generated constructor stub


		savingsBankService.addSavingsAccount( new SbAccount(100,"Harikrishnan",100));

		savingsBankService.addSavingsAccount(new SbAccount(10,"Krishnan",1000));

		savingsBankService.addSavingsAccount( new SbAccount(12,"Amal",500));
		
		savingsBankService.addSavingsAccount( new SbAccount(12,"Amal",500));

	
	
	}
	
	
	/***
	 * Testing the Savings account addition
	 */

	@Test
	public void testAddSavingsAccount() {
		
		int expectedValue = 1;
		
		int actualValue =2;
	    
		SbAccount sb1=new SbAccount(12,"Amal",200);
	    
		savingsBankService.addSavingsAccount(sb1);
	    
		List<SbAccount> sbTemp=  savingsBankService.getallSavingsBankDeposite();
	    
		Iterator<SbAccount> iterator = sbTemp.iterator();
	    
		while(iterator.hasNext())
	    {
	    	SbAccount sb2 = iterator.next();
	    	
	    	/*Checking by id and getting the occurrence of account*/

	    if(sb1.getAccountNumber()==sb2.getAccountNumber())
	    		{
	    	
	    	       expectedValue = ++expectedValue;
	    		}
	    }
	    
	    
        assertEquals(expectedValue, actualValue);
	}

	/***
	 * Testing the Updation of existing Sb Account
	 */
	
	@Test
	public void testUpdateExistingSavingsAccount() {
		
		
		String expected="Hari";
		
		float expectedAmount=1000.f;
		
		float actualAmount =0.0f;
		
		int expectedSize=3;
		
		int actualSize=0 ;
		
		
		
		String actual = null;

		SbAccount sb1=new SbAccount(100,"Hari",1000);
	    
		savingsBankService.updateExistingSavingsAccount(sb1);;
		
		SbAccount sb2=savingsBankService.getSavingsBankByAccountNumber(100);
		
		savingsBankService.getallSavingsBankDeposite();
	    
		actual=sb2.getAccountHolderName();
	    
		actualAmount=sb2.getAmount();
        
		actualSize =savingsBankService.getallSavingsBankDeposite().size();
	    
		assertEquals(expected,actual);
	    
		assertEquals(expectedAmount, actualAmount,0.0f);
	    
		assertEquals(expectedSize, actualSize);
		
		
	}

}

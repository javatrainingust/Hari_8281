/***
 * ClassName:LoanAccountController
 * 
 * Description:Class for getting all the loan Account details
 * 
 * Date-15-10-2020
 */

package com.training.walmart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.account.model.CurrentAccount;
import com.training.account.model.LoanAccount;
import com.training.accountcollection.service.LoanAccountService;
/***
 * 
 * Class annotated with Restcontroller spring create LoanAccountController class
 * 
 * 
 * 
 */

@RestController
public class LoanAccountController {
	
	/*LoanAccount service class object is created using autowired annotation*/

	@Autowired
	private LoanAccountService loanAccountService;
	

	
	
	/**
	 * url /loanAccounts to this method 
	 * 
	 * call service class method addLoanAccount and then 
	 * 
	 * Return LoanAccount obj
	 * 
	 *
	 * @return loanAccount
	 */
	
	@RequestMapping(value="/loanAccounts",method=RequestMethod.POST)
	public LoanAccount addLoan(@RequestBody LoanAccount loanAccount)
	{
		loanAccountService.addLoanAccount(loanAccount);
	
		
		return loanAccount;
	}
	
	

	/***
	 * Url ending with /loanAccounts mapped to get all deposite method
	 * 
	 * 
	 * @return loanDepositeList 
	 * getting all the loan accounts
	 */	
	
	
	
	@RequestMapping(value="/loanAccounts",method=RequestMethod.GET)
	public List<LoanAccount> getAllDeposite()
	{

	List<LoanAccount> loanDepositeList =loanAccountService.getallLoanAccounts();
	
	
		return loanDepositeList;
	}
	

/***
* Method for getting the details of an Loan account by account number and Returning the object
*
* @param id -passing through query string
* 
* @return - loanAccount
*/


	@RequestMapping(value="/loanAccounts/{id}",method=RequestMethod.GET)
	public LoanAccount getLoanAccount(@PathVariable int id)
	{
		LoanAccount loanAccount = loanAccountService.getLoanAccountByAccountNumber(id);
	
		
		return loanAccount;
	}
	
	/***
	* Method for getting the details of an Loan account by account number and deleting
	* 
	* the account using id by passing it to deleteBankAccount(id)
	*
	* @param id -passing through query string
	* 
	* 
	*/


		@RequestMapping(value="/loanAccounts/{id}",method=RequestMethod.DELETE)
		public void deleteLoanAccount(@PathVariable int id)
		{
			 loanAccountService.deleteLoanBankAccount(id);
		
		

		}
		
		/***
		 * url /loanAccounts/{id} Mapped to this method 
		 * 
		 * this method call updateExistingLoanAccount using
		 * 
		 * loanBankService and passing the loanObject
		 * 
		 * Get the object from request body
		 * 
		 * 
		 * @return loanAccount
		 */
		
		@RequestMapping(value="/loanAccounts/{id}",method=RequestMethod.PUT)
		public LoanAccount updateLoan(@PathVariable int id,@RequestBody LoanAccount loanAccount)
		{
			
			loanAccountService.updateExistingLoanAccount(loanAccount);
		
			
			return loanAccount ;
		}
		

		/***
		 *  /sortLoanAccounByName url maps to this method
		 * 
		 *  this method gets  sorted Loanlist by name 
		 * 
		 * @param model - store Loanlist in model
		 * 
		 * @return loanDepositeList
		 */
		
		@RequestMapping("/sortLoanAccountByName")
		public String  sortLoanAccountByName(Model model)
		{
			List<LoanAccount> loanAccounts = loanAccountService.getAllLoanAccountSortByHolderName();
			
			model.addAttribute("loanList",loanAccounts);
			
			return "loanDepositeList";
		}


		/***
		 *  /sortLoanAccounByOutstanding url maps to this method
		 * 
		 *  this method gets  sorted Loanlist by name 
		 * 
		 * @param model - store Loanlist in model
		 * 
		 * @return loanDepositeList
		 */
		
		
		
		
		@RequestMapping("/sortLoanAccountByOutstanding")
		public String  sortLurrentAccountByBalance(Model model)
		
			{
				List<LoanAccount> loanAccounts = loanAccountService.getAllLoanAccountSortByOutstanding();
				
				model.addAttribute("loanList",loanAccounts);
				
				return "loanDepositeList";
		}
		
}

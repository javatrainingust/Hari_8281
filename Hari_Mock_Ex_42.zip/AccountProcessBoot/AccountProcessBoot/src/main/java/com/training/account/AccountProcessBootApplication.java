package com.training.account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountProcessBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountProcessBootApplication.class, args);
		System.out.println("Hi");
	}

}

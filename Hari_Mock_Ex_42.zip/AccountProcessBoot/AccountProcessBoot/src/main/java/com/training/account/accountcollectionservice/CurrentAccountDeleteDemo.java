/**
 * ClassName:CurrentAccountDeleteDemo
 * 
 * Description:MainMethod for Processing Delete Functionality 
 * 
 * Date-06-10-2020
 * */



package com.training.account.accountcollectionservice;


/***
 * Class is for invoking current account delete operation
 * this class contain main method and the execution is getting statrted here.
 *
 */
public class CurrentAccountDeleteDemo {

	
	/***
	 * Invoking the methods like getallCurrentAccounts deleteCurrentAccountByAccountNumber in the current 
	 * 
	 * service class
	 * 
	 *  */

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CurrentAccountService currentAccountService = new CurrentAccountService();
	
	currentAccountService.getallCurrentAccounts();
	currentAccountService.deleteCurrentAccountByAccountNumber(1000);
		
		System.out.println("After Delete");


		currentAccountService.getallCurrentAccounts();
		
	}

}

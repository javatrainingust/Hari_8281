/***
 * ClassName : CurrentAccountSortDemo
 * 
 * Description:Main method for sorting CurentAccount by holdername and Overdraft
 * 
 * Date-07-10-2020
 */


package com.training.account.accountcollectionservice;


/***
 * Main method where the execution started for sorting the current account by holders name and OverDraft
 * 
 * Calling CurrentAccountservice class methods using the Service object 2 methods getAllCurrentAccountSortByHolderName()
 * 
 * getAllCurrentAccountSortByAccountOverDraft
 * 
 */



public class CurrentAccountSortDemo {

	
	/***
	 * 
	 * Main Method
	 * 	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CurrentAccountService service = new CurrentAccountService();
		
		System.out.println("List Before Sorting");
		
		service.getallCurrentAccounts();
		
        System.out.println("");
		
		System.out.println("List After Sorting");
		
		System.out.println("-------------");
		

		service.getAllCurrentAccountSortByHolderName();
		
		
	    System.out.println("");
		
		System.out.println("Sorting by Amount");
		

        System.out.println("--------------------");
		
		 service.getAllCurrentAccountSortByAccountOverDraft();
		
        
		
		

	}

}

/***
 * ClassName:FixedDepositeAddDem
 * 
 * Description:Inpitting values using addFixedDepositemethod
 * 
 * 
 *Date-08-10-2020
 */



package com.training.account.accountcollectionservice;

import java.security.Provider.Service;

import com.training.account.model.FixedDeposite;

/***
 * 
 * Class for initiating adding fd account without duplication
 * 
 */


public class FixedDepositeAddDemo {

	/***
	 * 
	 * MainMethod
	 * 
	 * */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FixedDepositeService fdDepositeService = new FixedDepositeService();
		
		System.out.println("Adding new Accounts.............");
		
		System.out.println(".............");
		
	    fdDepositeService.addFixedDepositeAccount(new FixedDeposite(1001,"Manu",100,6));
		

	    fdDepositeService.addFixedDepositeAccount(new FixedDeposite(999,"Suku",110,5));
	    

	    fdDepositeService.addFixedDepositeAccount(new FixedDeposite(1000,"Hari",120,8));
	    
	    fdDepositeService.addFixedDepositeAccount(new FixedDeposite(1000,"Hari",120,8));
	    
	    fdDepositeService.getAllFixedDposites();
	    

	    System.out.println("Updating existing Accounts.............");
		
		System.out.println(".............");
		
	    fdDepositeService.updateExistingFixedDepositeAccount(new FixedDeposite(1000,"HariKrishnan",1220,8));
	    
	    fdDepositeService.getAllFixedDposites();
	    
	}

}

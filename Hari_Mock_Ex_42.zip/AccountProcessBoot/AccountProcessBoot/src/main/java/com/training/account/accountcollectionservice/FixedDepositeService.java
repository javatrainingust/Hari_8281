/**
 * ClassName:FixedDepositeService
 * 
 * Description:Service class for processing
 * 
 * Date-06-10-2020
 * */




package com.training.account.accountcollectionservice;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.account.dataaccess.FixedDepositeDao;
import com.training.account.dataaccess.FixedDepositeDaoImplementation;
import com.training.account.model.FixedDeposite;
import com.training.account.model.LoanAccount;
import com.training.account.model.FixedDeposite;

/***
 * This class is mainly for three activities
 * 
 * 1.Getting the list of Fd accounts insde the list
 * 
 * 2.Getting the fd account details by passing account number
 * 
 * 3.Deleting a particular fd account by account number
 * 
 * @Service is used for creating FixedDepositeService 
 * 
 */

@Service
public class FixedDepositeService {
	
	/*FixedDepositeDao class object is created using autowired annotation*/


	@Autowired
	private FixedDepositeDao dao;
	/***
	 * Constructor of this class for creating the object of fdImplementation class
	 * 
	 * for calling both the constructor and methods inside the implementation class
	 * 
	 */
	public FixedDepositeService()
	{
		
	// dao = new FixedDepositeDaoImplementation();
	 
	}
	
	/**
	 * Operation 1 - Getting all the fd details 
	 * 
	 * 2.Displaying 
	 * 
	 * 3.Returning the fd list to  Main method class(fd-retrieval ) test
	 * 
	 * */
	
	public List<FixedDeposite> getAllFixedDposites()
	{
		List<FixedDeposite> fDeposites = dao.getAllFixedDeposites();
		/*
		 * Iterator<FixedDeposite> iterator = fDeposites.iterator();
		 * 
		 * while(iterator.hasNext()) { FixedDeposite fdeposite =iterator.next();
		 * 
		 * 
		 * System.out.println("");
		 * 
		 * System.out.println("Name of Account Holder           -"+fdeposite.
		 * getAccountHolderName());
		 * 
		 * System.out.println("Account number of Account Holder -"+fdeposite.
		 * getAccountNumber());
		 * 
		 * System.out.println("Tenure of Account Holder          -"+fdeposite.getTenure(
		 * ));
		 * 
		 * System.out.println("Amount of Account Holder          -"+fdeposite.getAmount(
		 * ));
		 * 
		 * }
		 * 
		 */
		return fDeposites;
	}
	
     /**
      * Getting the FixedDeposite details by account number 
      * 
      * Display the details 
      * 
      * Return the Fdobject to test and the FdRetrivalClass
      *  
      * */
	
	public FixedDeposite getFixedDepositeByAccountNumber(int accountNumber)
	{
		FixedDeposite fDepositeAccount=dao.getFixedDepositeByAccountNumber(accountNumber);
		
		
		System.out.println("Name Of Account Holder     - "+fDepositeAccount.getAccountHolderName());
		
		System.out.println("Account number of Account Holder -"+fDepositeAccount.getAccountNumber());
		
		System.out.println("Tenure of Account Holder          -"+fDepositeAccount.getTenure());
		
		System.out.println("Amount of Account Holder          -"+fDepositeAccount.getAmount());
	    
		
		
		return fDepositeAccount;
	}
	
	/**
	 * Deleting the fdAccount by accountNumber*/
	
	public void deleteFixedDepositeAccount(int accountNumber)
	{
		dao.deleteFixedDepositeByAccountNumber(accountNumber);
		
		
	}
	
	/***
	 * Method for getting sorted list of FdAccount by holdername,Returning the sorted set 
	 * 
	 * and displaying the sorted list (Using -Stream)
	 * 
	 */
	public List<FixedDeposite> getAllFixedDepositeSortByHolderName()
	{
		List<FixedDeposite> fixedDeposites= dao.getAllFixedDeposites();
		
		//Collections.sort(fixedDepositeList);
		
    Stream<FixedDeposite> fixedDepositeStream = fixedDeposites.stream();
	    
	    Stream<FixedDeposite> fixedDepositeSortedStream= fixedDepositeStream.sorted();
	    
	    List<FixedDeposite> fixedDepositeList = fixedDepositeSortedStream.collect(Collectors.toList());
		
		
		
		Iterator<FixedDeposite> iterator = fixedDepositeList.iterator();
		
		while(iterator.hasNext())
		{
			FixedDeposite fDeposite = iterator.next();
			
			System.out.println("");
			
			System.out.println("Name of Account Holder           -"+fDeposite.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+fDeposite.getAccountNumber());
			
			System.out.println("Tenure of Account Holder          -"+fDeposite.getTenure());
			
			System.out.println("Amount of Account Holder          -"+fDeposite.getAmount());
		
			
		}
		return fixedDepositeList;
	}
	
	/***
	 * Method for getting sorted list of FdAccount by Holder's balance amount ,Returning the sorted set by 
	 * 
	 * and displaying the sorted list (Using -Stream)
	 * 
	 */
	
	public List<FixedDeposite> getAllFixedDepositeSortByAccountBalance()
	{
		List<FixedDeposite> fixedDepositeAmountSortingList = dao.getAllFixedDeposites();
		
	//	Collections.sort(fixedDepositeAmountSortingLists, new BalanceComparator());

	Stream<FixedDeposite> FixedDepositeSalaryStream = fixedDepositeAmountSortingList.stream();
		
		Stream<FixedDeposite> FixedDepositeSalarySortStream = FixedDepositeSalaryStream.sorted(new BalanceComparator());;
		
		List<FixedDeposite> fixedDepositeAmountSortingLists = FixedDepositeSalarySortStream.collect(Collectors.toList());
		
		Iterator<FixedDeposite> iterator = fixedDepositeAmountSortingLists.iterator();
		
		while(iterator.hasNext())
		{
			FixedDeposite fixedDeposite = iterator.next();
			
			System.out.println("");
			
			System.out.println("Name of Account Holder           -"+fixedDeposite.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+fixedDeposite.getAccountNumber());
			
			System.out.println("Tenure of Account Holder          -"+fixedDeposite.getTenure());
			
			System.out.println("Amount of Account Holder          -"+fixedDeposite.getAmount());
		
		
	}
	
	return fixedDepositeAmountSortingLists;
}

	/***
	 * 
	 * Displaying the added fdAccount status id the fdaccount is already present or not
	 * 
	 * 	 */

	public void addFixedDepositeAccount(FixedDeposite fixedDeposite)
	{
		boolean isAdded= dao.addFixedDepositeAccount(fixedDeposite);
		
		if(isAdded)
		{
			System.out.println("fdAccount added Successfully");
			
		}
		
		else
		{
		
			System.out.println("Duplicate Fd Account");
			
		}
		
	}
	/***
	 * Updating an Existing fd  Account
	 */
	
	public void updateExistingFixedDepositeAccount(FixedDeposite fixedDeposite)
	{
		
		dao.updateExistingFixedDepositeAccount(fixedDeposite);
		
	}
	
	
}

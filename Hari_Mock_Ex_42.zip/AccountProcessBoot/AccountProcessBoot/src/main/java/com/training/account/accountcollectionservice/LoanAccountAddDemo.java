/***
 * ClassName:LoanAccountAddDemo
 * 
 * Description:Initiation of loan Account add and update process
 * 
 * date -08-10-2020
 */


package com.training.account.accountcollectionservice;

import com.training.account.model.LoanAccount;

/***
 * Initiation of loan Account add and update process
 * 
 */

public class LoanAccountAddDemo {

	
	/***
	 * 
	 * Main method Execution begins here call to Loan service class
	 * */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub


	      LoanAccountService accountService = new LoanAccountService();

		 
       System.out.println("Adding new Accounts.............");
		
		System.out.println(".............");
		
		accountService.addLoanAccount(new  LoanAccount(1001,"Manu",110,500));
		
		accountService.addLoanAccount( new  LoanAccount(1000,"Hari",100,1000));
		
		accountService.addLoanAccount( new  LoanAccount(1002,"Suku",120,300));
		
		accountService.addLoanAccount( new  LoanAccount(1002,"Suku",120,300));
		
		accountService.getallLoanAccounts();

		 
      System.out.println("updating Exicting Accounts.............");
		
		System.out.println(".............");
		
		accountService.updateExistingLoanAccount(new  LoanAccount(1002,"Sukumar",1200,300));
		
		accountService.getallLoanAccounts();
		
	}

}

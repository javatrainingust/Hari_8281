/***
 * ClassName:SavingBankService
 * 
 * Description:Service class for the implementation of SavingBankDaoImplementation
 * 
 * Date-06-10-2020
 */


package com.training.account.accountcollectionservice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.account.dataaccess.SavingsBankDao;
import com.training.account.dataaccess.SavingsBankDaoImplementations;

import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;

/***
 * SavingsBankService Class is used for 
 * 
 * 1.Displaying all savings Bank account
 * 
 * 2.Displaying particular savings Bank account by accountNumber
 *
 * 3.Delete the Savings Bank Account by accountNumber
 * 
 * @Service is used for creating SavingsBankService
 */
@Service
public class SavingsBankService {
	
	/*SavingsBankDao class object is created using autowired annotation*/
	
	@Autowired
	private SavingsBankDao dao; 

	/**
	 * Constructor used for creating SavingsBankDaoImplementation Object
	 * 
	 * */
    
	public SavingsBankService(){
		
		//dao=new SavingsBankDaoImplementations();
	
	
	}
	/**
	 * This method display all the account details inside the sb List and 
	 * Returning the retrieved List to Service and test class
	 * */
	
	public List<SbAccount> getallSavingsBankDeposite()
	{
		List<SbAccount> sbAccounts= dao.getAllSavingsBankDeposite();
		
		/*
		 * Iterator<SbAccount> iterator = sbAccounts.iterator();
		 * 
		 * while(iterator.hasNext()) { SbAccount sb =iterator.next();
		 * 
		 * 
		 * System.out.println("");
		 * 
		 * System.out.println("Name of Account Holder           -"+sb.
		 * getAccountHolderName());
		 * 
		 * System.out.println("Account number of Account Holder -"+sb.getAccountNumber()
		 * );
		 * 
		 * 
		 * System.out.println("Amount of Account Holder          -"+sb.getAmount());
		 * 
		 * }
		 */
	
		
		return sbAccounts;
	}
	
/**
 * Getting the SbAccount details using AccountNumber ,display the details and return the 
 * specified object
 * 
 * */
	
	public SbAccount getSavingsBankByAccountNumber(int accountNumber)
	{
		SbAccount sbAccount=dao.getSavingsBankByAccountNumber(accountNumber);
		
		
		System.out.println("Name Of Account Holder     - "+sbAccount.getAccountHolderName());
		
		System.out.println("Account number of Account Holder -"+sbAccount.getAccountNumber());
		
		
		System.out.println("Amount of Account Holder          -"+sbAccount.getAmount());
		
		
		return sbAccount;
	}
	
	/**
	 * Delete the SbAccount using Account number
	 * */
	
	public void deleteSavingsBankAccount(int accountNumber)
	{
		dao.deleteSavingsBankByAccountNumber(accountNumber);
		
		
	}
	
	
	/***
	 * Method for getting sorted list of Sb account  by name,Returning the sorted set 
	 * 
	 * and displaying the sorted list (Using -Stream)
	 * 
	 */
	
	public List<SbAccount> getAllSbAccountSortByHolderName()
	{
		List<SbAccount> sbAccountLists= dao.getAllSavingsBankDeposite();
		
	//	Collections.sort(sbAccountList);
		
		Stream<SbAccount> sbAccountStream = sbAccountLists.stream();
		
		Stream<SbAccount> sbAccountSortedStream = sbAccountStream.sorted();
		
		List<SbAccount> sbAccountList = sbAccountSortedStream.collect(Collectors.toList());
		
		Iterator<SbAccount> iterator = sbAccountList.iterator();
		
		while(iterator.hasNext())
		{
			SbAccount savingsAccount = iterator.next();
			
			System.out.println("");
			
			System.out.println("Name of Account Holder           -"+savingsAccount.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+savingsAccount.getAccountNumber());
				
			System.out.println("Amount of Account Holder          -"+savingsAccount.getAmount());
			
		
			
		}
		return sbAccountList;
	}
	
	/***
	 * Method for getting sorted list of Sb account by Holder balance amount ,Returning the sorted set by 
	 * 
	 * and displaying the sorted list (Using -Stream)
	 * 
	 */
	
	public List<SbAccount> getAllSbAccountSortByAccountBalance()
	{
		List<SbAccount> SbAccountAmountSortingList = dao.getAllSavingsBankDeposite();
		
		//Collections.sort(SbAccountAmountSortingLists, new AccountBalanceComparator());

		Stream<SbAccount> sbAccountSalaryStream = SbAccountAmountSortingList.stream();
		
		Stream<SbAccount> sbAccountSalarySortStream = sbAccountSalaryStream.sorted(new AccountBalanceComparator());;
		
		List<SbAccount> SbAccountAmountSortingLists = sbAccountSalarySortStream.collect(Collectors.toList());
		
		Iterator<SbAccount> iterator = SbAccountAmountSortingLists.iterator();
		
		while(iterator.hasNext())
		{
			SbAccount sbAccount = iterator.next();
			

			System.out.println("");
			
			System.out.println("Name of Account Holder           -"+sbAccount.getAccountHolderName());
			
			System.out.println("Account number of Account Holder -"+sbAccount.getAccountNumber());
				
			System.out.println("Amount of Account Holder          -"+sbAccount.getAmount());
			
		
		
	}
	
	return SbAccountAmountSortingLists;
}
	

	/***
	 * 
	 * Displaying the added SavingsAccount and printing account is already present or not
	 * 
	 * 	 */

	public void addSavingsAccount(SbAccount savingsAccount)
	{
		boolean isAdded= dao.addSavingsAccount(savingsAccount);
		
		if(isAdded)
		{
			System.out.println("SavingsAccount added Successfully");
			
		}
		
		else
		{
		
			System.out.println("Duplicate Savings Account");
			
		}
		
	}
	/***
	 * Updating an Existing Savings  Account
	 */
	
	public void updateExistingSavingsAccount(SbAccount savingsAccount)
	{
		
		dao.updateExistingSavingsAccount(savingsAccount);
		
	}
	
	/***
	 * Retrieving the accounts on the basis of particular amount
	 * @param amount from the controller
	 * @return sbaccount list
	 */
	
	public List<SbAccount> getSbAccountBaisedOnAmount(float amount)
	{
		List<SbAccount> accounts = dao.getAllSavingsBankDeposite();
		
		List<SbAccount> sbAccount =new ArrayList();
		
		for(SbAccount sb:accounts)
		{
			if(sb.getAmount()>amount)
			{
				sbAccount.add(sb);
			}
			
		}
		
		return sbAccount;
	}
	
	


	
}

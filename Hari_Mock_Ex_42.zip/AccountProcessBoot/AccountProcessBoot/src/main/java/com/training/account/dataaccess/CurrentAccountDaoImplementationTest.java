/***
 * ClassName:CurrentAccountDaoImplementationTest
 * 
 * Description:Testing for all methods in  CurrentAccountDaoImplementation
 * 
 * Date - 06-10-2020
 * 
 */






package com.training.account.dataaccess;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.training.account.model.CurrentAccount;
import com.training.account.model.SbAccount;

public class CurrentAccountDaoImplementationTest {
	
	CurrentAccountDao dao = new CurrentAccountDaoImplementation();
	
	CurrentAccount ca = new CurrentAccount();

	/*Testing Getting method*/
	
	@Test
	public void testGetAllCurrentAccount() {

		int expected=3;
		List<CurrentAccount> actual=dao.getAllCurrentAccount();
		assertEquals(expected,actual.size());
	}

	/*Testing Getting particularAccount*/
	
	@Test
	public void testGetCurrentAccountByAccountNumber() {
	String expectedValue="Hari";
		
		ca=dao.getCurrentAccountByAccountNumber(1000);
		
		String actualValue=ca.getAccountHolderName();
		
		assertEquals(expectedValue,actualValue);
	}
 
	/*Testing delete method*/
	@Test
	public void testDeleteCurrentAccountkByAccountNumber() {
		int expectedSize=2;
		dao.deleteCurrentAccountkByAccountNumber(1000);
		List<CurrentAccount> actual=dao.getAllCurrentAccount();
		assertEquals(expectedSize, actual.size());
	}

}

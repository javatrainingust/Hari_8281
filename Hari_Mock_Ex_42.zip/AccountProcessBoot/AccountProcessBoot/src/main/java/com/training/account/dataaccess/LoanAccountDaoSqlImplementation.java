/***
 *ClassName : LoanAccountDaoSqlImplementation
 *
 * Description:This Is for the sql implementation of LoanAccount
 * 
 * Date:24-10-2020
 */


package com.training.account.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.account.model.LoanAccount;
/***
 * 
 * This class is annotated with the repository annotation for creating the object
 * and it implements the loan dao and overrides all the un implemented method in Dao
 */


@Repository
public class LoanAccountDaoSqlImplementation implements LoanAccountDao {

	@Autowired
	private JdbcTemplate jdbcTemplateObject;
	
	

	
	
	
	/***
	 * Retrieving all the Loan account and returning the list  to the controller
	 */
	
	
	@Override
	public List<LoanAccount> getAllLoantAccount() {
		// TODO Auto-generated method stub
	
		String sql ="SELECT * FROM loanaccount";
		
		List<LoanAccount> loanAccounts =jdbcTemplateObject.query(sql,new LoanAccountMapper());
		return loanAccounts;
	}
	
	/***
	 * Retrieving the LoanAccount by Account number and returning the object to the controller
	 */

	@Override
	public LoanAccount getLoanAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub

	
		String sql ="select * from loanaccount where accountNumber=?";
		
		LoanAccount loanAccount=(LoanAccount) jdbcTemplateObject.queryForObject(sql, new Object[] {accountNumber}, new LoanAccountMapper());
		
	
		
		return loanAccount;
	}
	
	/***
	 * Deleting the Account number no return type 
	 */

	@Override
	public void deleteLoanAccountkByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		String sql="delete  from loanaccount where accountNumber='"+accountNumber+"'";
		jdbcTemplateObject.update(sql);

	}
	
	/***
	 * Inserting an account by passing loan account obj as parameter and returning a boolean
	 */

	@Override
	public boolean addLoanAccount(LoanAccount loanAccount) {
		// TODO Auto-generated method stub
		
		String sql = "INSERT INTO loanaccount"+
		             "(accountNumber,holderName,amount,outstandingAmount) VALUES (?,?,?,?)";
		
		jdbcTemplateObject.update(sql,new Object[] {loanAccount.getAccountNumber(),loanAccount.getAccountHolderName(),loanAccount.getAmount(),loanAccount.getOutstandingAmount()});
	
		
		return true;
	}
	/***
	 * Updating the existing loan account
	 */

	@Override
	public void updateExistingLoanAccount(LoanAccount loanAccount) {
		// TODO Auto-generated method stub
		String query="update loanaccount set holderName='"+loanAccount.getAccountHolderName()+"',amount='"+loanAccount.getAmount()+"',outstandingAmount ='"+loanAccount.getOutstandingAmount()+"'  where accountNumber='"+loanAccount.getAccountNumber()+"'";

		jdbcTemplateObject.update(query);

	}

}

/***
 * ClassNAme:SavingsBankDaoImplementation
 * 
 * Description:Implementing Saving bank dao
 * 
 * Date-06-10-2020
 */





package com.training.account.dataaccess;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;


/***
 * 
 * Implementing all the abstract methods in savingsbank dao
 * 
 * @repository is used for creating SavingsBankDaoImplementation
 */

public class SavingsBankDaoImplementations implements SavingsBankDao {

	/*Adding to list invoking objects in constructors*/
	
	List savingsBank;
	
	private Set savingsBankSet;
	
	public  SavingsBankDaoImplementations() {
		// TODO Auto-generated constructor stub
		savingsBank = new ArrayList<SbAccount>();
		
		savingsBankSet= new HashSet<SbAccount>();
		
		SbAccount sb1 = new SbAccount(100,"Harikrishnan",100);
		

		SbAccount sb2 = new SbAccount(10,"Krishnan",1000);
		

		SbAccount sb3 = new SbAccount(12,"Amal",500);
		
		
	     savingsBank.add(sb1);
	     
	     savingsBank.add(sb2);
	     
	     savingsBank.add(sb3);
	     
	     savingsBankSet.add(sb1);
	     

	     savingsBankSet.add(sb2);

	     savingsBankSet.add(sb3);
	     
	
	}
	
	
	/*Getting*/
	
	@Override
	public List<SbAccount> getAllSavingsBankDeposite() {
		// TODO Auto-generated method stub
		return savingsBank;
	}
	
	/*Getting by accnt num*/

	@Override
	public SbAccount getSavingsBankByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		
		SbAccount sbDeposite=null;
		
		Iterator<SbAccount> iterator=savingsBank.iterator();
		
		while(iterator.hasNext())
		{
		   SbAccount sb=iterator.next();
		   
			if(sb.getAccountNumber()==accountNumber)
			{
				sbDeposite=sb;
			}
		}
		return sbDeposite;
	}
	
	/*Deleting by accnt num*/

	@Override
	public void deleteSavingsBankByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		
		SbAccount sbDeposite=null;
		
		Iterator<SbAccount> iterator = savingsBank.iterator();
		while(iterator.hasNext())
		{
			SbAccount sbAccount=iterator.next();
			
			if(sbAccount.getAccountNumber()==accountNumber)
			{
				
				sbDeposite=sbAccount;
			}
			
			
		}
		
		savingsBank.remove(sbDeposite);
	}

	/***
	 * Adding SbAccount with out duplicate method called from service class
	 */

	@Override
	public boolean addSavingsAccount(SbAccount sbAccount) {
		// TODO Auto-generated method stub
	boolean isAdded= savingsBankSet.add(sbAccount);
		
		if(isAdded)
		{
			
			savingsBank.add(sbAccount);
		}
		
	return isAdded;
	}

	/***
	 * Update and existing Sb Account .method calling from sbService class
	 */

	@Override
	public void updateExistingSavingsAccount(SbAccount sbAccount) {
		// TODO Auto-generated method stub
		
		Iterator iterator = savingsBank.iterator();

		while(iterator.hasNext())
		{
		       SbAccount sb = (SbAccount) iterator.next();
			
			if(sb.getAccountNumber()==sbAccount.getAccountNumber())
			{
				
				sb.setAccountHolderName(sbAccount.getAccountHolderName());
				
				sb.setAmount(sbAccount.getAmount());
			}
			
			
		}
		
	}

}

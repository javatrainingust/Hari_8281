/***
 * ClassName:SbMapper
 * 
 * Description:Its the mapper class which implements RowMapper
 * 
 * Date-24-10-2020
 * 
 */

package com.training.account.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.tree.RowMapper;

import com.training.account.model.SbAccount;
/***
 * This class contains the implemented method  MapRow of the Row mapper interface
 * 
 * 
 */
public class SbMapper implements org.springframework.jdbc.core.RowMapper<SbAccount>{
	
	

		
		/***
		 * MapRow is overridden method which is setting value to the object from resultset
		 * 
		 * And returning the sbAccount Object
		 */
		@Override
		public SbAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		
			SbAccount sbAccount = new SbAccount();
			
			sbAccount.setAccountNumber(rs.getInt("accountNumber"));
			
			sbAccount.setAccountHolderName(rs.getString("holderName"));
			
			sbAccount.setAmount(rs.getFloat("amount"));
			
			
			return sbAccount;
		}

	

}

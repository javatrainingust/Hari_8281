package com.training.account.fdmanagingservice;

import java.sql.Date;

import javax.xml.crypto.Data;

import com.training.account.model.FixedDeposite;
import com.training.account.model.RenewalAccount;

public class RenewalManagementService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		RenewalAccount r = new FixedDeposite();
		r.autoRenewal(6);

	}

}

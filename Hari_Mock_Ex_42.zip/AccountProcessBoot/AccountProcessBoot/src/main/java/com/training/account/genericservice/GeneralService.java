package com.training.account.genericservice;

import com.training.account.model.Account;

import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;
import com.training.account.util.IntrestCalculator;

/**Genaral service 
 * 1.doing downcasting
 * 2.calling base class methods*/

public class GeneralService {
	
	public static void main(String args[])
	{
		
		SbAccount sb=new SbAccount();
		FixedDeposite fd= new FixedDeposite();
		
		
		sb.setAccountNumber(0010);
		sb.setAccountHolderName("Harikrishnnan");
		sb.setAmount(1000);
		

	    fd.setAccountNumber(1110);
		fd.setAccountHolderName("prabha");
		fd.setAmount(5000);
		
		
		Account[] accounts={new Account(),sb,fd};
		
		IntrestCalculator Ic=new IntrestCalculator();
		/*For each loop for getting each Account*/
		for(Account account:accounts) {
			
			account.calculateIntreast(fd.getAmount(), Ic);
			
			if(account instanceof FixedDeposite) {
		
				FixedDeposite fd1 = (FixedDeposite)account;
				fd1.updateRenewal("yes");
				
			}
		}
		
	}

}

/**
 * Classname:InterestCalculatorPremium 
 * 
 * Description:Class for calculating Premium Intrerest.Overloading is implemented here..
 * 
 * Date:30/09/2020
 * */



package com.training.account.util;

public class InterestCalculatorPremium implements ICalculator{

	
	/**
	 * Implementing Method in interface ICalculator for,
	 * 
	 *  calculating Sb interest for premium members
	 *  
	 *  Call coming from account service class and call may Generalservice class
	 */
	
	@Override
	public float calculateDepositeIntrest(float Amount, int year, float R) {
		// TODO Auto-generated method stub
		float Interest=Amount*year*10000;
		System.out.println(" Intrest processing");
		System.out.println("********************");
		System.out.println(" ");
		System.out.println("SB Premium"+Interest);
		return Interest;
	}

	
	
	/**Implementing Method in interface ICalculator and,
	 * 
	 * Using that calculating FD interest for premium members
	 * 
	 * Call coming from AccountService class and call may from General service class
	 */
	
	@Override
	public float calculateDepositeIntrest(float Amount, int year) {
		// TODO Auto-generated method stub
		System.out.println(" Intrest processing");
		System.out.println("********************");
		System.out.println(" ");
		float Interest=Amount*year*10000;
		System.out.println("Fd Premium"+Interest);
		return Interest;
	}
	

}

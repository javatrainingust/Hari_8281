/***
 * ClassName:SbAccountController
 * 
 * Description:Class for getting all the savings bank details
 * 
 * Date-15-10-2020
 */
package com.training.account.walmartcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.account.accountcollectionservice.SavingsBankService;
import com.training.account.model.CurrentAccount;
import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;
/***
 * 
 * Class annotated with Restcontroller spring create SbAccountController class
 * 
 * 
 * 
 */
@RestController
public class SbAccountController {
	/*SavingsBank service class object is created using autowired annotation*/
	@Autowired
	private SavingsBankService savingsBankService;


	
	/***
	 *url /savings  is mapped to this method 
	 * 
	 * Calling the service method for adding the sb account 
	 * 
	 * Returning sbAccount Object
	 * Method is post request 
	 * @param sbAccount
	 * @return sbAccount
	 */
	@PostMapping("/savings")
	public SbAccount addSavings(@RequestBody SbAccount sbAccount)
	{
		savingsBankService.addSavingsAccount(sbAccount);
	
		
		return sbAccount ;
	}
	

	/***
	 * Url ending with /savings mapped to get all deposite method
	 * 
	 * Method has get request
	 * 
	 * @return sbDepositeList 
	 * 
	 * getting all the savings account and adding list and return
	 */	
	
	
	
	
	
	@GetMapping("/savings")
	public List<SbAccount> getAllDeposite()
	{
		
	
	
		List<SbAccount> savingDepositeList =savingsBankService.getallSavingsBankDeposite();	
		
	
		
		return savingDepositeList;
	}

/***
* Method for getting the details of an Savings account by account number and assignig
* 
* to object  and the method has get request
*
* @param id -passing through query string
* 
* @return - returning sb object
*/


	@GetMapping("/savings/{id}")
	public SbAccount getSbAccount(@PathVariable int id)
	{
		SbAccount sb =savingsBankService.getSavingsBankByAccountNumber(id);
		
		
		
		return sb;
	}

	/***
	* Method for deleting SbAccount
	* 
	*/

	@DeleteMapping("/savings/{id}")
		public void deleteSbAccount(@PathVariable int id)
		{
			savingsBankService.deleteSavingsBankAccount(id);
			
			
			
		}
		
		/***
		 * url /saving/{id} Mapped to this method 
		 * 
		 * this method call updateExistingSavingsAccount using
		 * 
		 * savingsBankService and passing the sbObject
		 * 
		 * @param id and object
		 * 
		 * @return SbAccount
		 */
	
	@PutMapping("/savings/{id}")
		public SbAccount updateSavings(@PathVariable int id,@RequestBody SbAccount sbAccount)
		{
		
	
			savingsBankService.updateExistingSavingsAccount(sbAccount);
		
	
			return sbAccount ;
		}
	/***
	 * /savings-amount/{amount} maps to this method for getting sb accounts
	 * 
	 * on the basis of amount
	 * 
	 * @param amount coming from url
	 * @return sblist to service class
	 */
	@GetMapping("/savings-amount/{amount}")
	public List<SbAccount> retriveAccountByBalance(@PathVariable float amount)
	{
		List<SbAccount> resultSb=savingsBankService.getSbAccountBaisedOnAmount(amount);

		return resultSb;
		
	}
		
		/***
		 *  /sortSbAccounByName url maps to this method
		 * 
		 *  this method gets  sorted sblist by name 
		 * 
		 * @param model - store sblist in model
		 * 
		 * @return sbList
		 */
		
		
		
		@RequestMapping("/sortSbAccountByName")
		public String  sortSavingsAccountByName(Model model)
		{
			List<SbAccount> sbAccounts = savingsBankService.getAllSbAccountSortByHolderName();
			
			model.addAttribute("sbList",sbAccounts);
			
			return "sbDepositeList";
		}
	
		/***
		 *  /sortSbAccounByBalance url maps to this method
		 * 
		 *  this method gets  sorted sblist by name 
		 * 
		 * @param model - store sblist in model
		 * 
		 * @return sbList
		 */
		
		
		
		
		@RequestMapping("/sortSbAccountByBalance")
		public String  sortSavingsAccountByBalance(Model model)
		{
			List<SbAccount> sbAccounts = savingsBankService.getAllSbAccountSortByAccountBalance();
			
			model.addAttribute("sbList",sbAccounts);
			
			return "sbDepositeList";
		}
}

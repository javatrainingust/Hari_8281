/****
 * ClassName:AccountProcessBootApplicationTests
 * 
 * Description:Class For testing the functionality
 * 
 * Date:28-10-2020
 */




package com.training.account.AccountProcessBoot;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoSettings;
import org.springframework.boot.test.context.SpringBootTest;

import com.training.account.accountcollectionservice.SavingsBankService;
import com.training.account.dataaccess.SavingsBankDaoImplementations;
import com.training.account.model.SbAccount;


/***
 * 
 * This testing class contains the test methods 
 */
@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class AccountProcessBootApplicationTests {

	/*Mocking dao*/
	@Mock
	private SavingsBankDaoImplementations SavingBankDaoMock;
	/*Injecting the mock*/
	
	@InjectMocks
	private SavingsBankService Bankingservice;
	
	/***
	 * Testing all the accounts on the basis of Particular amount
	 */
	
	@Test
	void testGetAllSbByAmount() {
		
		SbAccount sbAccount = new SbAccount();
		sbAccount.setAmount(1000);
		
		SbAccount sbAccount1 = new SbAccount();
		sbAccount1.setAmount(2000);
		
		SbAccount sbAccount2 = new SbAccount();
		sbAccount2.setAmount(3000);
		
		SbAccount sbAccount3 = new SbAccount();
		sbAccount3.setAmount(4000);
		
		SbAccount sbAccount4 = new SbAccount();
		sbAccount4.setAmount(5000);
		
		List<SbAccount> sbAccounts = new ArrayList<SbAccount>();
		
		sbAccounts.add(sbAccount);
		sbAccounts.add(sbAccount1);
		sbAccounts.add(sbAccount2);
		sbAccounts.add(sbAccount3);
		sbAccounts.add(sbAccount4);
		when(SavingBankDaoMock.getAllSavingsBankDeposite()).thenReturn(sbAccounts);
		
		assertEquals(4,Bankingservice.getSbAccountBaisedOnAmount(1000).size());
	}
	

}



		
		
		


	
	
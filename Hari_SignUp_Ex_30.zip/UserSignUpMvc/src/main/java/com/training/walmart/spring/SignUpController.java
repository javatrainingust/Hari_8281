/***
 * ClassName:SignUpController
 * 
 * Description:Controller class for sign up
 * 
 * Date-15-10-2020
 */

package com.training.walmart.spring;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.walmart.springmodel.SignUp;
/***
 * Controller class named Signup controller annotated by @controller
 * 
 * 
 * contains 2 methods for mapping show form and processform
 * 
 * 
 */
@Controller
public class SignUpController {
	
	/**For creating the object of model and adding to model attribut this value is taken by
	 * 
	 * Signup form also returning a string signup
	 * 
	 * requestmapping annotation maps the /form url 
	 * */
	
	@RequestMapping("/form")
    public String showForm(Model model)
     {
		SignUp signUp = new SignUp();
		
		model.addAttribute("user",signUp);
		return "signup";
		}
	
	/***
	 * Process method return the conformDignup Page for printing message
	 */
	
	@RequestMapping("/processForm")
	public String precessForm(@ModelAttribute("user") SignUp userSignup)
	{
		
		return "confirmSignUp";
	}

}

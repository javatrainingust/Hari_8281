/***
 * ClassName:SignUp

 * 
 * Description:This class is act as model
 * 
 * Date:15-10-2020
 * 
 */


package com.training.walmart.springmodel;

/***
 * Model class of SignupModel
 * 
 * signUpvariable and getters and setter
 * 
 */




public class SignUp {
	
	
	String userName;
	String userId;
	String userPassword;
	String confirmPassword;
	
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getUserPassword() {
	return userPassword;
}
public void setUserPassword(String userPassword) {
	this.userPassword = userPassword;
}
public String getConfirmPassword() {
	return confirmPassword;
}
public void setConfirmPassword(String confirmPassword) {
	this.confirmPassword = confirmPassword;
}

}

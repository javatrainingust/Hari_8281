/****
 * ClassName : AboutMeController
 * 
 * Description:It is the controller Call from the url comming here
 * 
 * Date-14-10-2020
 * 
 */


package com.training.walmart.ust;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/***
 * 
 * It is the Controller contains A method getMyHobbies
 * 
 * Also controller annotation create the object of the class Aboutmecontroller
 */


@Controller
public class AboutMeController {

	/***
	 * This Method returns a string that string is the name of the jsp page 
	 * 
	 *which resides inside the view folder inside the Web-inf .Request mapping annotation
	 *
	 *Mapping the url
	 */
	
	@RequestMapping("/hobbies")
	public String getMyHobbies()
	{
		
		return "hobbie";
	}
}

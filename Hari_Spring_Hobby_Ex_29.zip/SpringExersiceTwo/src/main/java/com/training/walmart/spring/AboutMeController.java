/***
 * ClassName:AboutMeController
 * 
 *Description:Loading aboutMe and MyHobbies jsp page
 *
 *Date :14-10-2020
 * 
 */


package com.training.walmart.spring;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
/***
 * 
 * This class is annotated with controller annotation
 * 
 * and this class contain two methods 
 * 
 */
@Controller
public class AboutMeController {

	/***
	 * This class is called when url contain /form and request mapping is doing mapping
	 *
	 * and returning about me aboutme.jsp
	 */
	@RequestMapping("/form")
	public String showForm()
	{
		return"aboutMe";
	}
	
	/***
	 * This method takes one parameter as input whis is hobby passing to myHobby and 
	 * 
	 * creating a model attribute and returning the myHobbie page
	 * @param myHobby
	 * @param model
	 * @return
	 */
	
	
	@RequestMapping("/processForm")
	public String process(@RequestParam("hobby") String myHobby ,Model model)
	{
		myHobby = myHobby.toUpperCase();
		
		String result = "My hobby is     " +myHobby;
		
		model.addAttribute("message",result);
		return "myHobbies";
	}
	
}

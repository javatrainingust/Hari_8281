/***
 * ClassName:HomePageController
 * 
 *Description:Class which is loading the homepage
 *
 *Date-14-10-2020
 */


package com.training.walmart.spring;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/***
 * Class is annotated with controller
 * 
 * This class is used for loading the home page 
 * 
 */
@Controller
public class HomePageController {
	/***
	 *loading home page while project is running / represents root 
	 *
	 * Returning home page jsp
	 *
	 */
	@RequestMapping("/")
	public String homePage() {
		
		return"home";
	}

}

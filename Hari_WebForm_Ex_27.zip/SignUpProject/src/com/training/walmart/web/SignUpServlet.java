package com.training.walmart.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.walmart.webmodel.SignUpModel;

/**
 * Servlet implementation class SignUpServlet
 */
@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 * 
	 * 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * 
	 * Setting values to signupmodel by invoing settermethod and retriving the value from front end parameter using getter method
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		SignUpModel signupmodel = new SignUpModel();
		signupmodel.setUserName(request.getParameter("Uname"));
		signupmodel.setUserId(request.getParameter("Uid"));
		signupmodel.setUserPassword(request.getParameter("Upassword"));
		signupmodel.setConfirmPassword(request.getParameter("UCpassword"));
		request.setAttribute("key", signupmodel);
		request.getRequestDispatcher("displayDetails.jsp").forward(request, response);
	}

}

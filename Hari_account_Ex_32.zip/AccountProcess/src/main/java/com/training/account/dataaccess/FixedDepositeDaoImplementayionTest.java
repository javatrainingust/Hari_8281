/***
 * ClassName:FixedDepositeDaoImplementayionTest
 * 
 * Description:Test class for the FixedDeposite
 * 
 * Date-06-10-2020
-*/


package com.training.account.dataaccess;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.training.account.model.FixedDeposite;

/***
 * 
 * Testing the AddAccunt and updateaccount features in Fd dao implementation
 */

public class FixedDepositeDaoImplementayionTest {


	
	FixedDepositeDao dao= new FixedDepositeDaoImplementation();

	/* Retrieving Method Search  */
	
	@Test
	public void testGetAllFixedDeposites() {
	
		int expected=3;
		
		List<FixedDeposite> actual=dao.getAllFixedDeposites();
		
		assertEquals(expected,actual.size());
	}

	/*Search Method Testing*/
	
	@Test
	public void testGetFixedDepositeByAccountNumber() {
		
		String expectedValue="Hari";
		
		FixedDeposite fd = new FixedDeposite();
		
		fd=dao.getFixedDepositeByAccountNumber(1000);
		
		String actualValue=fd.getAccountHolderName();
		
		assertEquals(expectedValue, actualValue);
		
		}

	/*Delete Method Testing*/
	
	@Test
	public void testDeleteFixedDepositeByAccountNumber() {
		
		int expectedSize=2;
		
		dao.deleteFixedDepositeByAccountNumber(1000);
		
		List<FixedDeposite> actual=dao.getAllFixedDeposites();

		assertEquals(expectedSize, actual.size());
			
	
	}

}
	

/***
 * ClassName:SavingsBankDaoImplementationTest
 * 
 * Description:Testing The SavingsBankDaoImplementation Class methods
 * 
 * Date- 06-10-2020
 */


package com.training.account.dataaccess;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;


public class SavingsBankDaoImplementationTest {
	

	SavingsBankDao dao= new SavingsBankDaoImplementations();	
	SbAccount sd = new SbAccount();
	
    /*Getting test*/
	
	@Test
	public void testGetAllSavingsBankDeposite() {

	
		int expected=3;
		
		List<SbAccount> actual=dao.getAllSavingsBankDeposite();
		assertEquals(expected,actual.size());	}

	/*Getting by acct num testing*/
	
	@Test
	public void testGetSavingsBankByAccountNumber() {
		
		String expectedValue="Krishnan";
		
		sd=dao.getSavingsBankByAccountNumber(10);
		
		String actualValue=sd.getAccountHolderName();
		
		assertEquals(expectedValue,actualValue);
		
}

	/*Delete By testing*/
	@Test
	public void testDeleteSavingsBankByAccountNumber() {

		int expectedSize=2;
		dao.deleteSavingsBankByAccountNumber(10);
		List<SbAccount> actual=dao.getAllSavingsBankDeposite();

		assertEquals(expectedSize, actual.size());

	}
}
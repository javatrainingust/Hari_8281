/**
 * Classname:FixedDeposite 
 * 
 * Description:Its one of the sub class for Account subclasses.Handiling Fd of a cusomer.
 * 
 * Date:30/09/2020
 * */


package com.training.account.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.training.util.ICalculator;
import com.training.util.IntrestCalculator;


import com.training.util.IntrestCalculator;


/**The class used for model FdAccount class.it is inheriting from Account class and implementing Comparable*/


public class FixedDeposite extends Account implements RenewalAccount,Comparable<FixedDeposite> {

	int tenure;
	
	private int accountNumber=10;
	
	boolean autoRenewal;
	
	String sDate;

    Date todate = new Date();

    Calendar calendar= Calendar.getInstance();
	
    IntrestCalculator ic=new IntrestCalculator();
	
    Calendar mycal=new GregorianCalendar(2020,8,20);
    
    Date MaturityDate=mycal.getTime();
    
    /**
     * Default fd Constructor
     */

    public FixedDeposite()
    {
    	System.out.println("Inside the Fixed Deposite Constructors");
    }
    
    /**
     * Parameterzed constructor
     * @param accountnumber
     * @param holdername
     * @param amount
     * @param tenure
     * Passing from serviceImplementationconstructorclass
     * 
     */
    
    
    
    
    public FixedDeposite(int accountnumber,String holdername,float amount,int tenure)
    {
    
    	super(accountnumber,holdername,amount);
    	
    	this.tenure=tenure;
    	
    	//System.out.println("Name"+holdername);
    	
    //	System.out.println("Holdername using Base class method"+ getAccountHolderName());
    }
    
    
    
    /**
     * Accessor Method for Tenure of fd
     */
	
	public int getTenure() {

		return tenure;
	
	}
	
	
	/**
	 * Accessory Method for Tenure of fd
	 */
	
	
	public void setTenure(int tenure) {
	
		this.tenure = tenure;
	
	}
	
	/**
	 * Accessor Method check wheather account is Autorenewable or not	
	 */
	
	
	public boolean isAutoRenewal() {
	
		return autoRenewal;
	
	}
	
	
	/**
	 * Accessory Method check wheather account is Autorenewable or not
	 */
	
	
	public void setAutoRenewal(boolean autoRenewaltemp) {
	
		autoRenewal = autoRenewaltemp;
	
	}
	
	/**
	 * Accessor Method for date 
	 * @return date
	 */
	
	public String getsDate() {
		return sDate;
	
	}
	/**
	 * Method for Updating Renewal status ,assigning values to autorenewal
	 */
	
	
	public void updateRenewal(String RenewalStatus) {	

		if(RenewalStatus.equals("yes"))
			this.autoRenewal=true;
	
		System.out.println("Renewal Status"+this.autoRenewal);
	
	}
	
	

	/**
	 * Overriding method of base class
	 */
	
	
public void calculateIntreast(float Amt,ICalculator calculator){

	
	float Interest=calculator.calculateDepositeIntrest(Amt,1);
	
	System.out.println("Fixed Intrest inside fd="+Interest);
	
	System.out.println("Name"+getAccountHolderName());
	
	System.out.println("   ");
	
	
	
	
}



/**
 * OverRidding autorenewal method in the Renewal interface
 */


public void autoRenewal(int tenure) {
	// TODO Auto-generated method stub

     SimpleDateFormat format =new SimpleDateFormat("yyyy-MM-dd");
    
     this.autoRenewal=true;
 	 
     if(autoRenewal==true)
 	 
 	 {
 		/*comparing maturitydate and currentdate to add the tenure*/
 		
 		
 		if(MaturityDate.compareTo(todate)<0 |MaturityDate.equals(todate))
 	
 		{
 			
 			calendar.add(Calendar.MONTH, tenure);
 		    
 			sDate =format.format(calendar.getTime());
 		    
 		    System.out.println("New Maturity Date"+sDate);
 		   

 		   
		    
 		}
 		
 	}
    

	
/*	if(renewalfeedback.equals("yes"))
	this.AutoRenewal=true;
	System.out.println("Renewal Status"+this.AutoRenewal);
	*/
}

/***
 * Overriding the Compareto method in comparable interface for sorting fdAccount by holder name
 * 
 */


public int compareTo(FixedDeposite fixedDeposite) {
	// TODO Auto-generated method stub
	
	return this.accountHolderName.compareTo(fixedDeposite.accountHolderName);
}


}




	



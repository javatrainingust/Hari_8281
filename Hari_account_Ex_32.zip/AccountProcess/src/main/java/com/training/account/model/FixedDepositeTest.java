/**
 * ClassName : FixedDepositeTest

 * 
 * Description: Testing methods in FixedDeposite
 * 
 * Date:01-10-2020
 * 
 */

package com.training.account.model;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

public class FixedDepositeTest {
	
	
/**
 * Testing UpdateRenewal method in FD class
 */
	
	FixedDeposite fixedDeposite= new FixedDeposite();
	
	
	@Test
	public void testUpdateRenewal() {
		
		
		boolean expectedBoolean = true;
		
		fixedDeposite.updateRenewal("yes");
		
		boolean actualBoolean=fixedDeposite.isAutoRenewal();
		
		assertEquals(expectedBoolean,actualBoolean);
	}
	
	
	/**
	 * Testing the Autorenewal method date testing processing
	 */
	
	
	@Test
	public void testautoRenewal() {
		
		String expectedDate="2021-04-01";
		
	    fixedDeposite.autoRenewal(6);
		
	    String actualDate=fixedDeposite.getsDate();
	 
	    /*Compaing String dates*/
	    
		assertEquals(expectedDate, actualDate);

	}

}

package com.training.account.service;

import com.training.account.model.Account;
import com.training.account.model.CurrentAccount;
import com.training.account.model.FixedDeposite;
import com.training.account.model.LoanAccount;
import com.training.account.model.SbAccount;
import com.training.util.ICalculator;
import com.training.util.InterestCalculatorPremium;
import com.training.util.IntrestCalculator;
/**Service Class*/
public class AccountService {
	/**Main method*/
	public static void main(String args[])
	{
		
	
		Account Act=new Account();
	 	SbAccount Sb=new SbAccount();
		FixedDeposite fd=new FixedDeposite();
		CurrentAccount ca=new CurrentAccount();
		LoanAccount la=new LoanAccount();
	    ICalculator calculator= new InterestCalculatorPremium(); 
	   
		/*setting values*/
		
		
		Act.setAccountNumber(10001);
		Act.setAccountHolderName("Hari");
	 	Act.setAmount(1000);
	 	
	 	/*Getting Values*/
		
	 	System.out.println("Bank Details");
	 	System.out.println("*******************");
		System.out.println("Account Holder name - " + Act.getAccountHolderName());
		System.out.println("Holder Id - " + Act.getAccountNumber());
		System.out.println("Account Balance - " + Act.getBalance());

		/*Processing*/

		System.out.println("Processing Withdrawal...........");
		Act.withdrawMoneym(1500);
	 	Act.calculateIntreast(Act.getAmount(),calculator);
	 	System.out.println(" ");
	 	
	 	/*SbProcessing*/
	 	
	 	System.out.println("SB Account Processing");
	 	System.out.println("*************************");

	 	Sb.setAccountNumber(50);
	 	Sb.setAccountHolderName("Balu");
	 	Sb.setAmount(50);
	 	Sb.updateBalance(Sb.getAmount());
	 	Sb.calculateIntreast(Sb.getAmount(),calculator);/*Calling method by passing amount and interface obj*/
			
		/*fd Processing*/
		
		fd.setAccountNumber(100);
		fd.setAccountHolderName("Hari");
		fd.setAmount(2000);
		fd.setTenure(6);
		
	/*fd.updateRenewal("yes");*/
		
		fd.updateBalance(fd.getAmount());
		fd.calculateIntreast(fd.getAmount(),calculator);/*Calling method by passing amount and interface obj*/
	
		ca.setAccountNumber(101);
		ca.setAmount(1500);
		ca.setAccountHolderName("Raj");
		ca.setOverdraft(ca.getAmount()*2);
		System.out.println("Overdraft"+ca.getOverdraft());
		la.updateBalance(fd.getAmount());
		
		la.setAccountNumber(102);
		la.setAccountHolderName("Ravi");
		la.setAmount(2000);
		la.updateBalance(la.getAmount());
		la.setTenure(2);;
		la.emiCalculation(ca.getAmount());
		
		
	   
		

		
	}

}

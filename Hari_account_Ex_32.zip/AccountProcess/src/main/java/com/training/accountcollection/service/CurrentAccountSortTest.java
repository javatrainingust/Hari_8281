/***
 * ClassName:CurrentAccountSortTest
 * 
 * Description: Testing name and holderAmount sorting
 * 
 * Date - 07-10-2020
 * 
 */


package com.training.accountcollection.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.training.account.model.CurrentAccount;
import com.training.account.model.FixedDeposite;


/***
 * Test Class for testing GetAllCurrentAccountSortByHolderName,GetAllCurrentAccountSortByAccountOverDraft
 * 
 * methods both resides in Current account service class
 * 
 */

public class CurrentAccountSortTest {


	CurrentAccountService service = new CurrentAccountService();
	 List<CurrentAccount> currentAccounts;
	
	/***
	 *  2 Testing
	 *  
	 *  1 by size of CurrentAccountList
	 *  
	 *  2  by First name comparison
	 */
	
	
	@Test
	public void testGetAllCurrentAccountSortByHolderName() {
		
		
		String expectedValue="Hari";
        currentAccounts	=service.getAllCurrentAccountSortByHolderName();
		String actualValue = currentAccounts.get(0).getAccountHolderName();
        assertEquals(expectedValue, actualValue);
        assertEquals(3, currentAccounts.size());
		
	
	}

	/***
	 *  2 Testing 
	 *  
	 *  1 by size of CurrentAccountList
	 *  
	 *  2  by First amount comparison
	 *  */
	
	@Test
	public void testGetAllCurrentAccountSortByAccountOverDraft() {
	
		

		float expected=300.f;
		  currentAccounts	=service.getAllCurrentAccountSortByAccountOverDraft();
			float actual = currentAccounts.get(0).getOverdraft();
			assertEquals(expected, actual,0.0f);
	        assertEquals(3, currentAccounts.size());
		
		
	}

}

package com.training.accountcollection.service;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.List;

import org.junit.Test;

import com.training.account.model.FixedDeposite;
import com.training.account.model.SbAccount;

public class FixedDepositeSeviceAddTest {

	FixedDepositeService fdDepositeService;
	
	/***
	 * Constructor for adding to list
	 */
	public FixedDepositeSeviceAddTest() {
		// TODO Auto-generated constructor stub
	
	 fdDepositeService = new FixedDepositeService();
		
	    fdDepositeService.addFixedDepositeAccount(new FixedDeposite(1001,"Manu1",100,6));
		

	    fdDepositeService.addFixedDepositeAccount(new FixedDeposite(999,"Suku",110,5));
	    

	    fdDepositeService.addFixedDepositeAccount(new FixedDeposite(1000,"Hari",120,8));
	    
	   
	}
	/***
	 * Testing the Fdaccount insertion into list
	 */
	
	
	@Test
	public void testAddFixedDepositeAccount() {
	    
	
		int expectedValue = 1;
		
		int actualValue =2;
	    
		FixedDeposite fd1=new FixedDeposite(1000,"Hari",120,8);
	    
		fdDepositeService.addFixedDepositeAccount(fd1);
	    
		List<FixedDeposite> FdTemp=  fdDepositeService.getAllFixedDposites();
	    
		Iterator<FixedDeposite> iterator = FdTemp.iterator();
	    
		while(iterator.hasNext())
	    {
	    	FixedDeposite fd2 = iterator.next();
	    	/*Checking by id and getting the occurrence of account*/

	    if(fd1.getAccountNumber()==fd2.getAccountNumber())
	    		{
	    	
	    	       expectedValue = ++expectedValue;
	    		}
	    }
	    
	    fdDepositeService.getAllFixedDposites();
	    
        assertEquals(expectedValue, actualValue);
	}
	
	
	/***
	 * Testing the fd account updation process
	 */

	@Test
	public void testUpdateExistingFixedDepositeAccount() {
		
		String expected="HariKrishnan";
		
		float expectedAmount=1200.f;
		
		float actualAmount =0.0f;
		
		int expectedSize=3;
		
		int actualSize=0 ;
		
		
	String actual = null;
	
	FixedDeposite fd1=new FixedDeposite(1000,"HariKrishnan",1200,8);
    
	fdDepositeService.updateExistingFixedDepositeAccount(fd1);
	
	FixedDeposite fd2 =fdDepositeService.getFixedDepositeByAccountNumber(1000);
	
	actual=fd2.getAccountHolderName();
	
	actualAmount=fd2.getAmount();
	
	actualSize =fdDepositeService.getAllFixedDposites().size();
	
	
	assertEquals(expected,actual);
	
	assertEquals(expectedAmount, actualAmount,0.0f);
	
	assertEquals(expectedSize, actualSize);
		
		
		
	}
	
	
}

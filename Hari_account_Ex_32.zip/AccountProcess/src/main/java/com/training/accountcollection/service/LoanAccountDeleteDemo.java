/**
 * ClassName:LoanAccountDeleteDemo 
 * 
 * Description:MainMethod for Processing Delete Functionality 
 * 
 * Date-06-10-2020
 * */





package com.training.accountcollection.service;

/***
 * This class is used for deleting the Loan accounts by creating the obj of service class and for 
 * 
 * calling loanservice class methods for delete
 * 
 */

public class LoanAccountDeleteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	LoanAccountService  loanAccountService = new LoanAccountService();
		
	loanAccountService.getallLoanAccounts();	
	loanAccountService.deleteLoanBankAccount(1000);
	System.out.println("After Delete");

	loanAccountService.getallLoanAccounts();
				

	}

}

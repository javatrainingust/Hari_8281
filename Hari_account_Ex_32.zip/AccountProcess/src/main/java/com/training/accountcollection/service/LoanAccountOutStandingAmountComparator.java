/***
 * 
 * ClassName:LoanAccountoutstandingComparator
 * 
 * Descriptions:For comparing LoanAccount by OverDraft amount
 * 
 * Date-07-10-2020
 * 
 */



package com.training.accountcollection.service;

import java.util.Comparator;

import com.training.account.model.CurrentAccount;
import com.training.account.model.LoanAccount;

/***
 * This method implementing the Comparator and overriding the compare method
 * 
 */



public class LoanAccountOutStandingAmountComparator implements Comparator<LoanAccount> {
	
	/***
	 * 
	 * Getting the LoanAccount objects as the arguments and comparing and return assccending order result set
	 * 
	 */
	

	
	public int compare(LoanAccount loanAccount, LoanAccount loanAccount2) {
		// TODO Auto-generated method stub
		return (int) (loanAccount.getOutstandingAmount()-loanAccount2.getOutstandingAmount());
	}


}

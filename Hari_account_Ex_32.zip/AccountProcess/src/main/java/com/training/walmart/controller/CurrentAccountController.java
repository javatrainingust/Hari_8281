/***
 * ClassName:CurrentAccountController
 * 
 * Description:Class for getting all the current account details
 * 
 * Date-15-10-2020
 */

package com.training.walmart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.account.model.CurrentAccount;
import com.training.accountcollection.service.CurrentAccountService;


@Controller
public class CurrentAccountController {

	
	/*CurrentAccount service class object is created using autowired annotation*/
	
	@Autowired
	private CurrentAccountService  currentAccountService;

	/***
	 * Url ending with /CurrentAccount mapped to get all deposite method
	 * 
	 * @param model
	 * @return currentDepositeList page in view
	 * getting all the current account and adding to model 
	 */
	
	@RequestMapping("/CurrentAccount")
	public String getAllDeposite(Model model)
	{
		System.out.println("Inside the controller getallCurrentAccounts");
	
		List<CurrentAccount> currentDepositeList =currentAccountService.getallCurrentAccounts();	
		
		model.addAttribute("currentList",currentDepositeList);
		
		return "currentDepositeList";
	}
/***
 * Method for getting the details of Current account by account number and assignig
 * 
 * to model
 *
 * @param id -passing through query string
 * @param model - Current account model used by current account view(viewCurrent Account)
 * @return - returning view (viewCurrent Account)
 */
	@RequestMapping("/viewCurrentAccount")
	public String getCurrentAccount(@RequestParam("id")String id,Model model)
	
	{
		CurrentAccount currentAccount = currentAccountService.getCurrentAccountByAccountNumber(Integer.parseInt(id));
		
		model.addAttribute("currentAccount",currentAccount);
		
		return "viewCurrentAccount";
	}
	
}

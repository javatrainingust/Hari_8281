/***
 * ClassName:Main
 * 
 * Description:Main method for Organiser
 * 
 * Date - 12-10-2020
 * 
 */




package com.training.walmart.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



/***
 * 
 *Main class contains main method and the execution starts here for the 
 *
 *organiser
 *
 */



public class Main {

	
	/***
	 * Getting the context from the SPringConfig class
	 * 
	 * getting bean object from spring config
	 * 
	 *  calling pojo class method
	 *  */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		Organiser organiser =  context.getBean("organiser",Organiser.class);
		
		organiser.sayGreeting();

	}

}

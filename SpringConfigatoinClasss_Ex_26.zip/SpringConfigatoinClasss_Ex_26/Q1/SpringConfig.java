/***
 * ClassName:SpringConfig
 * 
 * Descriptor:SpringConfiguration class
 * 
 * Date:13-10-2020
 * 
 */


package com.training.walmart.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/***
 *
 *Class For Configuring the bean
 * 
 *
 */


@Configuration
public class SpringConfig {
	
	/***
	 * Creating the organiser object and returning
	 * 
	 * @return Organiser object
	 */
	@Bean(name="organiser")
	public Organiser getOrganiser()
	{
		Organiser organiser = new Organiser();
		
		return organiser;
	}

}

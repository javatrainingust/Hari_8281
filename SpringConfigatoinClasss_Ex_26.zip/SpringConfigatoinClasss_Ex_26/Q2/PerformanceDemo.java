/***
 * ClassName:PerformanceDemo
 * 
 * Description:Exicution for Instrumentalist starts here
 * 
 * Date - 12-10-2020
 */




package com.training.walmart.secondspring;

import javax.naming.Context;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/***
 * 
 *In class performance we are creating path AnnotationapplicationContext obj for  musiccontext.xml
 *
 *Using path AnnotationapplicationContext obj we are accessing the Instrumentalist bean
 *
 *using instrumentalist we are accessing the perform method
 *
 *
 */

public class PerformanceDemo {

	
	/***
	 * 
	 * Main method  for instrumentalist
	 * 	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		AnnotationConfigApplicationContext annotationConfigApplicationContext = new AnnotationConfigApplicationContext(SpringConfiguration.class);
		
		Instrumentalist instrumentalist = annotationConfigApplicationContext.getBean("instrumentalist",Instrumentalist.class);
		
		instrumentalist.perform();

	}

}

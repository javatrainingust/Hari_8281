/***
 * ClassName:SpringConfiguration
 * 
 * Descriptions:Code ForConfiguratio
 * 
 * Date:13-10-2020
 * 
 */



package com.training.walmart.secondspring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/***
 * 
 * Class for SpringConfiguration code
 * 
 */

@Configuration
public class SpringConfiguration {
	
	/****
	 * Creating bean object  and returning
	 * 
	 *  instrumentalist object
	 */
	
	@Bean(name="instrumentalist")
	public Instrumentalist getInstrumentList()
	{
		System.out.println("Baby");
		Instrumentalist instrumentalist = new Instrumentalist();
		
		instrumentalist.setSaxaphonee(getSaxphone());
		
		return instrumentalist;
		
		
	}

	/***
	 * 
	 * Creating bean object and returning
	 * 
	 * saxaphone object
	 */
	
	@Bean
	public Saxaphone getSaxphone()
	{

		System.out.println("Baby123");
		Saxaphone saxaphone = new Saxaphone();
		
		return saxaphone;
		
	}
}

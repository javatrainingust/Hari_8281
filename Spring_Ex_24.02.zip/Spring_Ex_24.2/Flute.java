/***
 * ClassName:Flute
 * 
 * Description:Flute PoJO class
 * 
 * Date:12-10-2020
 * 
 */

package com.training.walmart.secondspring;

/***
*
* Class Implementing instrument and overriding the method play  in instrument
*
*/
public class Flute implements Instrument {

	/***
	 * Play method displays Playing Flute
	 */
	
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing Flute ................");
	}

}

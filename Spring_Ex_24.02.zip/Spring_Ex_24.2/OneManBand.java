/***
 * ClassName:OneManBand
 * 
 * Description:Operations for one band
 * 
 * Date:12-10-2020
 * 
 */



package com.training.walmart.secondspring;

import java.util.Iterator;
import java.util.List;

/***
 * 
 *This Class implements the performer interface and override the perform 
 *
 *method 
 *
 */

public class OneManBand implements Performer {

	
	List<Instrument> instruments;

	
	
	public List<Instrument> getInstruments() {
		return instruments;
	}

	public void setInstruments(List<Instrument> instruments) {
		this.instruments = instruments;
	}

	
	/***
	 * Perform iteration through the Instrument list
	 */
	
	public void perform() {
		// TODO Auto-generated method stub
		

		Iterator inIterator = instruments.iterator();
		
		while(inIterator.hasNext())
		{
			
			Instrument instrumentsList =(Instrument) inIterator.next();
		
			instrumentsList.play();

		}
		
	
		
		
	
		}
		
	
}

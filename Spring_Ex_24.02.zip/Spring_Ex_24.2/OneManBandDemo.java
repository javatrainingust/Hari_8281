/***
 * ClassName:OneManBandDemo
 * 
 * Description:Main method class,OnemanBand operations like perform starts here
 * 
 * Date:12-10-2020
 * 
 */

package com.training.walmart.secondspring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/***
 * 
 * class Contains Main
 */


public class OneManBandDemo {

	/***
	 * 
	 * Loading definitions from the xml in classpath 
	 * 
	 * Assignig the object of onemanband  using getbean
	 * 
	 * doing perform operation
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("instrumentContext.xml");
		
		OneManBand oneManBand = applicationContext.getBean("OneManBand",OneManBand.class);
		
		oneManBand.perform();

	}

}

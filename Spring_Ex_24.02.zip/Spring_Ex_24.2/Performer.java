/**
 * ClassName:Performer
 * 
 * Description:PerformerInterface
 * 
 * Date:12-10-2020
 * 
 */


package com.training.walmart.secondspring;
/***
 * 
 * Interface for declaring a method perform for a performer implemented by OneManBand
 */


public interface Performer {

	/*perform method declaration*/
	public void perform();
}

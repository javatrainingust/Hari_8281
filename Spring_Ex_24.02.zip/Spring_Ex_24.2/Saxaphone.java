/***
 * ClassName:Saxaphone
 * 
 * Description:Pojo class for saxaphone
 * 
 * Date-12-10-2020
 * 
 */




package com.training.walmart.secondspring;

/***
 *
 * Class Implementing instrument and overriding the play method in instrument
 *
 */


public class Saxaphone implements Instrument {

	/***
	 * Play method displays Playing saxsaphone
	 */
	
	public void play() {
	
	
		System.out.println("Playing Saxsaphone........");
		
		
		
	}

}

/***
 * ClassName:Main
 * 
 * Description:Main method for Organiser
 * 
 * Date - 12-10-2020
 * 
 */




package com.training.walmart.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;


/***
 * 
 *Main class contains main method and the execution starts here for the 
 *
 *organiser
 *
 */



public class Main {

	
	/***
	 * Getting the xml config path
	 * 
	 * Creating bean object 
	 * 
	 *  calling pojo class method
	 *  */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Organiser organiser =  context.getBean("organiser",Organiser.class);
		
		organiser.sayGreeting();

	}

}

/***
 *ClassName:Orginiser
 *
 *
 *Description;Organiser Pojo class 
 *
 * Date-12-10-2020
 */



package com.training.walmart.spring;

/***
 * 
 * Organiser class contain method name sayGreeting for printing the display
 *
 */


public class Organiser {

	/***
	 * Say greeting method is used for printng the message
	 */
	
	public void sayGreeting()
	{
		System.out.println("Welcome to the training");
		
	}
}

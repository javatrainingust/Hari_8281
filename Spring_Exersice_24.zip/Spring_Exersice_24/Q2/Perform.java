/***
 * InterfaceName:Perform
 * 
 * Description:Perform Interface for perform an operation
 * 
 * Date:12-10-2020
 * 
 */


package com.training.walmart.secondspring;

/***
 * 
 * Implemented by Singer Class .this class contain one method and can be implemented .
 * 
 * 
 */


public interface Perform {

	/* Method declaration for doing some performance*/
	
	public void perform();
}

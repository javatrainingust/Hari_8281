/***
 * ClassName: Singer
 * 
 * Description : pojo class for Singer
 * 
 * 
 * Date-12-10-2020
 * 
 */


package com.training.walmart.secondspring;

/***
 * Pojo class contains one variable Namme 
 * 
 * One constructor with one parameter  for initializing the name 
 * 
 *the constructor value is passed from the singer context.xml
 *
 *Implements perform interface
 * 
 */


public class Singer  implements Perform {
	
	
	String singerName;
	
	
	/***
	 * 
	 *parameterized constructor for initializing the name 
	 * 
	 */
	public Singer(String Name) {
	
	singerName = Name;
	
	}


	/***
	 * Override perform method 
	 *  
	 *  Process - printing the Name
	 *  
	 */
	public void perform() {
		
		System.out.println("Singer Name   "+singerName);
		
	}
	
	
	

}

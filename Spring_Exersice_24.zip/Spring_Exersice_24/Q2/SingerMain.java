/***
 * ClassName : singerMain
 * 
 * Description:SingerManin contains main method
 * 
 * Date: 12-10-2020
 * 
 */





package com.training.walmart.secondspring;

import org.springframework.aop.interceptor.ConcurrencyThrottleInterceptor;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/***
 * 
 *Class contain main method and execution starts here
 *
 */


public class SingerMain {

	/***
	 * 
	 * Main method
	 *
	 * bean(Singer)
	 * 
	 * Path object creation for the bean 
	 * 
	 * object creation for bean
	 *
	 * calling bean method 
	 * 
	 * 	 */
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*Path object for xml*/
		
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("singerContext.xml");

		Singer singer = applicationContext.getBean("singer",Singer.class);
		
		singer.perform();
	}

}

/***
 * ClassName : Instrumentalist
 * 
 * Description  : pojo Class for instrumentalist
 * 
 * 
 * Date -12-10-2020
 */


package com.training.walmart.secondspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/***
 * Class Implementing performer interface and contain perform fuction
 * 
 * One obj pramenter of type Saxsaphone 
 * 
 * using Autowiring for saxaphone (Saxaphone obj passing )
 *
 * 
 * 
 */

@Component("instrumentalist")
public class Instrumentalist implements Performer {

	@Autowired
	Saxaphone saxaphonee;



	/**
	 * Implemented perform method definition calling saxaphone implemented method play
	 *  
	 *  Implemented from Instrument
	 */
	
	public void perform()
	{
		/*play Method call in Saxsaphone */
		saxaphonee.play();
		
	
	}
}

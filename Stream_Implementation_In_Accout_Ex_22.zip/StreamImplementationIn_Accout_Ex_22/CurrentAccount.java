/**
 * Classname:CurrentAccount
 * 
 * Description:Its one of the sub class for Account subclasses.Its dealing with current account of a person.
 * 
 * Date:30/09/2020
 * */




package com.training.account.model;


import com.training.util.IntrestCalculator;


/**
 * The class used for model CurrentAccount class.it is inheriting from Account class and implementing Comparable
 */

public class CurrentAccount extends Account implements Comparable<CurrentAccount> {

	float overdraft;
	
	
	
	public CurrentAccount()
	{
		
		
	}
	
	public CurrentAccount(int accountnumber,String holdername,float amount,float overDraft) {
		super(accountnumber,holdername,amount);
		this.overdraft=overDraft;
	}


	/**
	 * Accessor Method for Account Overdraft
	 */
	
	public float getOverdraft() {
		return overdraft;
	}
	
	
	/**
	 * Accessory Method for Account overdraft
	 */
	
	public void setOverdraft(float overdraft) {
	overdraft = overdraft;
	}

	
	/***
	 * Overriding the Compareto method in comparable interface for sorting CurrentAccount by holder name
	 * 
	 */
	
	@Override
	public int compareTo(CurrentAccount currentAccount) {
		// TODO Auto-generated method stub
		return this.accountHolderName.compareTo(currentAccount.getAccountHolderName());
	}

	
	
}
